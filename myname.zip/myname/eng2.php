<?php
$conn = new mysqli('localhost', 'root', '', 'project');
if (!$conn){
    die(mysqli_error($conn));
}

function display_data(){
    global $conn;
    $query = "SELECT * FROM engner";
    $result = mysqli_query($conn, $query);
    return $result;
}

$result = display_data();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXPERIENCE REQUEST</title>
    <link rel="stylesheet" href="josy.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Downloading file</h2>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example3" class="display" style="min-width: 845px">
                                <thead>
                                    <tr text-align="center">
                                        <th>ID</th>
                                        <th>Onwer Name</th>
                                        <th>Land Use</th>
                                        <th>Compensation1</th>
                                        <th>Compensation2</th>
                                        <th>Perpared By</th>
                                        <th>role of Job</th>
                                        <th>Date</th>   
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                session_start();
                                while ($row = mysqli_fetch_assoc($result)){                                       
                                    ?>
                                    <tr>
                                        <td><?php echo $row['id'] ?></td> 
                                        <td><?php echo $row['owner_name']?></td>
                                        <td><?php echo $row['land_use']?></td>
                                        <td><?php echo $row['compensation1']?></td>
                                        <td><?php echo $row['compensation2']?></td>
                                        <td><?php echo $row['prepared_by_name']?></td>
                                        <td><?php echo $row['role_of_job']?></td>
                                        <td><?php echo $row['date']?></td>
                                    </tr>
                                    <?php
                                }
                                session_destroy();
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
