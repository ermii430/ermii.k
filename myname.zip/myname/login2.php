<?php
session_start();

// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "teste";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Prepare SQL query
    $sql = "SELECT * FROM register WHERE username = '$username' AND email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    // Check if user exists
    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_array($result);

        if($row['status'] == '0'){ // Check if account is deactivated
            // Account is inactive
            echo '<script>alert("Your account is deactivated!"); window.location.href = "login2.php";</script>';
        } else {
            // Check password
            if($row['password'] == $password){
                // Redirect user based on role
                switch($row['role']){
                    case 'admin':
                        $_SESSION['admin_name'] = $row['name'];
                        header('location: maretadmin.php');
                        break;
                    case 'user':
                        $_SESSION['user_name'] = $row['name'];
                        header('location: jiddu.php');
                        break;
                    case 'r.office':
                        $_SESSION['user_name'] = $row['name'];
                        header('location: Rec.php');
                        break;
                    case 's.admin':
                        $_SESSION['user_name'] = $row['name'];
                        header('location: leadmin.php');
                        break;
                    case 'engineer':
                        $_SESSION['user_name'] = $row['name'];
                        header('location: eng3.php');
                        break;
                    default:
                        echo '<script>alert("Invalid role");</script>';
                        break;
                }
            } else {
                // Incorrect password
                echo '<script>alert("Incorrect Password"); window.location.href = "login2.php";</script>';
            }
        }
    } else {
        // User is not registered
        $error = 'You are not registered!';
        echo '<script>alert("' . $error . '"); window.location.href = "login.html";</script>';
    }
}

// Close connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login_page</title>
    <link rel="stylesheet" href="logi.css">
    <style>
        body{
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    font-family: sans-serif;
    background: rgba(111, 128, 224);
}
.main{
    width: 350px;
    height: 500px;
    background: rgba(111, 128, 224);
    overflow: hidden;
    border-radius: 10px;
    box-shadow: 5px 30px 50px black;
}
#chk{
    display: none;

}
.signup{
    position: relative;
    width: 100%;
    height: 100%;
}
label{
    color: white;
    font-size: 35px;
    justify-content: center;
    display: flex;
    margin: 60px;
    font-weight: bold;
    cursor: pointer;
    transition: .5s ease-in-out;
    margin-bottom: 10px;

}

input{
    width: 60%;
    height: 20px;
    background: white;
    justify-content: center;
    display: flex;
    margin: 18px auto;
    padding: 10px;
    border: none;
    outline: none;
    border-radius: 50px;
    
    
}

button{
    width: 60%;
    height: 40px;
    margin: 10px auto;
    justify-content: center;
    display: block;
    color: white;
    background: rgb(43, 83, 194);
    font-size: 20px;
    font-weight: bold;
    margin-top: 18px;
    outline: none;
    border: none;
    border-radius: 10px;
    transition: .3s ease-in;
    cursor: pointer;
    box-shadow: 5px 20px 40px black;

}
/* Sidebar styling */
.sidebar {
    width: 200px;
    position: fixed;
    top: 0;
    left: 0;
}

.sidebar a {
    padding: 10px;
    text-decoration: none;
    color: #000;
    display: block;
    font-size: 20px;
}
.sidebar a:hover{
    color: #fff;
}


button:hover{
    background: rgba(20, 57, 105);
}
#chk:checked ~ .signup label{
    transform: scale(.6);
}
.password-container {
    position: relative;
    margin-bottom: 20px;
}

.password-container input {
    padding-right: 30px;
}
.login{
    margin-top: -30px;
}
.login p {
    margin-top: 20px;
    font-size: 18px;
    text-align: center;
    color: #fff;
}
.login p a {
    text-decoration: none;
    color: #333;
}

.login p a:hover {
    color: purple;
}
.password-input {
    position: relative;
    display: flex;
    margin-top: -14px;
}
.password-input .toggle-password {
    position: absolute;
    right: 78px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
}
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="index.html" class="active">HOME</a>
    </div>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="main">
        <h1><marquee direction="left"  style="font-family: serif; font-size: 30px;font-weight: bold; color: white;">WELL COME TO OUR SERVICE!</marquee></h1>
            <input type="checkbox" id="chk" aria-hidden="true">
            <div class="login">
                <label for="chk" aria-hidden="true">Login</label>
                <input type="text" name="username" placeholder="Username" required>
                <input type="email" name="email" placeholder="Email" required>
                <div class="password-input">
                    <input type="password" name="password" id="password" placeholder="Password" required>
                    <span class="toggle-password" onclick="togglePasswordVisibility()">
                        &#128065;
                    </span>
                </div>
                <button type="submit">Login</button>
                <?php if(isset($error)) { echo "<p>$error</p>"; } ?>
                <p>Don't have an account? <a href="login.html"><b>Sign up</b></a></p>
            </div> 
        </div>
    </form>

    <script>
       function onlyCharacters(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.KeyCode;
            if((ASCIICode > 64 && ASCIICode < 91) || (ASCIICode > 96 && ASCIICode < 123)){
                return true;
            } else {
                return false;
            }
        }
        
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById('password');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
            } else {
                passwordInput.type = 'password';
            }
        }
    </script>
</body>
</html>
