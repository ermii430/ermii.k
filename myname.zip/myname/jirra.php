<?php
// PHP code for database connection and form submission

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Update with your database password
$dbname = "project"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitizeInput($data, $conn) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Initialize variables
$name = $address = $province = $district = $village = $woreda = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $name = sanitizeInput($_POST["name"], $conn);
    $address = sanitizeInput($_POST["address"], $conn);
    $province = sanitizeInput($_POST["province"], $conn);
    $district = sanitizeInput($_POST["district"], $conn);
    $village = sanitizeInput($_POST["village"], $conn);
    $woreda = sanitizeInput($_POST["woreda"], $conn);

    // Insert data into database
    $sql = "INSERT INTO jirra (name, address, province, district, village, woreda)
            VALUES ('$name', '$address', '$province', '$district', '$village', '$woreda')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("New record created successfully"); window.location.href = "jirra.php";</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>land management system</title>
    <link rel="stylesheet" href="jirra.css">
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }
    
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
    
        .sidebar ul li {
            padding: 10px;
            background: black;
        }
    
        .sidebar ul li a {
            text-decoration: none;
            color: #fff;
        }
        .sidebar a:hover{
            color: red;
        }
    
    </style>
    <script type="text/javascript">
        function onlyNumberKey(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 31 &&(ASCIICode < 48 || ASCIICode > 57)){
                return false;
            }
        }
        function onlyCharacters(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 64 && (ASCIICode < 91 || ASCIICode > 96 && ASCIICode < 123)){
                return true;
            }
            else{
                return false;
            }
        }
    </script>
</head>

<body>
    <div class="sidebar">
        <ul>
          <li><a href="index.html">Home</a></li>
        </ul>
      </div>
    <div class="all">
        <div class="day">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label>number</label>
                <input type="text" onkeypress="return onlyNumberKey(event)" name="number" required><br><br>
                <label>day</label>
                <input type="text" name="day" required>
            </form>
        </div>
        <div class="nav">
        <h2>contract for the gift of agricultural land</h2>
        <h3>gift agreement</h3>
    
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="row">
            <label>name</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="name" placeholder="name" required><br><br>
            <label>address</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="address" placeholder="address" required><br><br>
            <label>province</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="province" placeholder="province" required>
            <label>district</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="district" placeholder="district" required><br><br>
            <label>village</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="village" placeholder="village" required>
            <label>woreda</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="woreda" placeholder="woreda" required><br><br>
            <h3>the recipient agreement</h3>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="name" placeholder="name" required><br><br>
            <label>address</label>
            <input type="text"onkeypress="return onlyCharacters(event)" maxlength="11" name="address" placeholder="address" required><br><br>
            <label>province</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="province" placeholder="province" required>
            <label>district</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="district" placeholder="district" required><br><br>
            <label>village</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="village" placeholder="village" required>
            <label>woreda</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="woreda" placeholder="woreda" required><br><br>
    </div>
</div>

<input type="submit" value="Submit" class="submit-button">
<a href="yew.php">next</a>
</form>

    </div>
</body>

</html>
