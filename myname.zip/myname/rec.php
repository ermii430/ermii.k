<?php
$con= new mysqli('localhost','root','','myshop');
if ($con->connect_error) {
  die("connection failed:".$con->connect_error);
  if(!$con){
    die(mysqli_error($con));
  }
}
?>