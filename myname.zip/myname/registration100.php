<?php


// Database connection

$servername = "localhost";

$username = "root";

$password = "";

$database = "project";


// Create connection

$conn = new mysqli($servername, $username, $password, $database);


// Check connection

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}


// Function to sanitize input data

function sanitizeInput($data, $conn)

{

    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');

    return mysqli_real_escape_string($conn, $data);

}


// Check if form is submitted

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Initialize an empty array to store selected utilities and infrastructure

    $selectedUtilities = [];


    // Checkboxes for utilities and infrastructure

    $checkboxes = array('waterSupply', 'electricityConnection', 'sewerSystem');


    // Loop through each checkbox to check if it's checked

    foreach ($checkboxes as $checkbox) {

        if (isset($_POST[$checkbox])) {

            // If checked, add the label to the array

            $selectedUtilities[] = $checkbox; // Add the checkbox name

        }

    }


    // Check if road access is checked

    $roadAccess = isset($_POST['roadAccess']) ? 'Road Access' : '';


    // Check if public transportation is checked

    $publicTransportation = isset($_POST['publicTransportation']) ? 'Nearest Public Transportation' : '';


    // Sanitize declaration and signature

    $declaration = sanitizeInput($_POST['declaration'], $conn);

    $signature = sanitizeInput($_POST['signature'], $conn);


    // Handle file upload if needed

    $targetDirectory = "./uploads2/";


    if (!file_exists($targetDirectory)) {

        mkdir($targetDirectory, 0777, true);

    }


    $targetFile = $targetDirectory . basename($_FILES["documents"]["name"]);

    $allowedTypes = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

    $uploadOk = 1;

    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));


    if (!in_array($fileType, $allowedTypes)) {

        echo "<script>alert('Only PDF, DOC, DOCX, JPG, JPEG, and PNG files are allowed.');</script>";

        $uploadOk = 0;

    }


    if ($uploadOk == 0) {

        echo "<script>alert('Your file was not uploaded due to an error.');</script>";

    } else {

        if (move_uploaded_file($_FILES["documents"]["tmp_name"], $targetFile)) {

            echo "<script>alert('The file " . htmlspecialchars(basename($_FILES["documents"]["name"])) . " has been uploaded.');</script>";

        } else {

            echo "<script>alert('Your file was not uploaded due to an error.');</script>";

        }

    }


    // SQL query to insert data into the database

    $sql = "INSERT INTO life (utilities_infrastructure, access_and_transportation, declaration, signature, document) 

            VALUES ('" . implode(", ", $selectedUtilities) . "', '$roadAccess, $publicTransportation', '$declaration', '$signature', '$targetFile')";


    if ($conn->query($sql) === TRUE) {

        // If the record is inserted successfully, display an alert

        echo '<script>alert("New record created successfully");</script>';

    } else {

        echo "Error: " . $sql . "<br>" . $conn->error;

    }

}


// Close connection

$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Land Registration Form</title>
    <link rel="stylesheet" href="registration100.css">
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
            
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #000;
        }

        .sidebar a:hover {
            color: red;
        }

    </style>
</head>
<body>
<div class="sidebar">
        <ul>
            <li><a href="index.html">Home</a></li>
        </ul>
    </div>
    <div class="love">

        <div class="container">
            <h2>Land Registration Form</h2>
        </div>
        <div class="container">
            <form action="#" method="post" enctype="multipart/form-data">
                <label>Utilities and Infrastructure:</label>
                <input type="checkbox" id="waterSupply" name="waterSupply">
                <label for="waterSupply">Water Supply</label>
                <input type="checkbox" id="electricityConnection" name="electricityConnection"> <label
                    for="electricityConnection">Electricity Connection</label>
                <input type="checkbox" id="sewerSystem" name="sewerSystem"> <label for="sewerSystem">Sewer
                    System</label>
        </div>
        <div class="container">
            <label>Access and Transportation:</label>
            <input type="checkbox" id="roadAccess" name="roadAccess"> <label for="roadAccess">Road Access</label>
            <input type="checkbox" id="publicTransportation" name="publicTransportation">
            <label for="publicTransportation">Nearest Public Transportation</label>
        </div>
        <div class="container">
            <label for="documents">Attach Deed, Survey Maps, or Any Relevant Documents:</label>
            <input type="file" id="documents" name="documents" required>
        </div>
        <div class="container">
            <label>Declaration:</label>
            <textarea rows="8" name="declaration" cols="10"></textarea>
        </div>
        <div class="container">
            <label for="signature">Signature:</label>
            <input type="text" id="signature" name="signature" required>
        </div>
        <button type="submit">Submit</button>
        </form>
    </div>

</body>

</html>