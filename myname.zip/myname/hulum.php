<?php
// Perform connection validation
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Connection failed
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input data
function sanitizeInput($data) {
    global $conn; // Access the database connection inside the function
    $data = mysqli_real_escape_string($conn, $data); // Use mysqli_real_escape_string to prevent SQL injection
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// PHP validation and database insertion code
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $username = sanitizeInput($_POST['username']);
    $date = sanitizeInput($_POST['date']);
    $message = sanitizeInput($_POST['message']);
    $role = sanitizeInput($_POST['role']);

    // Check if 'seen' checkbox is checked
    $seen = isset($_POST['seen']) ? 1 : 0;

    // Check if checkbox is required
    if (!$seen) {
        // If checkbox is not checked, display error message
        echo "<script>alert('Please confirm if the message has been seen.');</script>";
    } else {
        // Insert data into database
        $sql = "INSERT INTO admin1 (username, date, seen, message, role) 
                VALUES ('$username', '$date', '$seen', '$message', '$role')";

        if ($conn->query($sql) === TRUE) {
            // Display success message
            echo "<script>alert('Record inserted successfully!');</script>";
        } else {
            // Display error message
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            width: 50%;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border-radius: 3px;
            border: 1px solid #ccc;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
        }

        .checkbox-group label {
            margin-left: 5px;
        }

        .form-group input[type="checkbox"] {
            margin: 0;
        }

        .form-group input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 3px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }

        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }
        select[name="role"] {
            display: block;
            margin: 0 auto;
        }
        select[name="role"] {
    width: 40%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 30px;
    background-color: #f9f9f9;
    margin-top: 10px; /* Increase the top margin to create space */
}

select[name="role"]:focus {
    outline: none;
    border-color: #007bff;
}

/* Style for the dropdown arrow */
select[name="role"]::-ms-expand {
    display: none;
}

/* Style for the dropdown arrow in Chrome */
select[name="role"]::-webkit-select-placeholder {
    color: #aaa;
}
    </style>
</head>
<body>
    <div class="login-container">
        <h2>ADMINISTRATION</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="username">Name:</label>
                <input type="text" id="username" name="username" maxlength="15" required>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group checkbox-group">
                <input type="checkbox" id="seen" name="seen" required>
                <label for="seen">Seen</label>
            </div>
            <div class="form-group">
                <textarea rows="8" cols="60" placeholder="Message" name="message"></textarea>
            </div>
            <select name="role" required>
                <option value="Land use Planning">Land use Planning</option>
                <option value="Rent-Agreement">Rent Agreement</option>
                <option value="Gift-Agreement">Gift Agreement</option>
                <option value="Site plan">Site plan</option>
                <option value="Regulatory reporting">Regulatory reporting</option>
                <option value="Budget and Finance">Budget and Finance</option>
            </select><br><br>
            <div class="form-group">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</body>
</html>
