<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input data
function sanitizeInput($data, $conn)
{
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return mysqli_real_escape_string($conn, $data);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize each input field
    $landownerName = sanitizeInput($_POST['landownerName'], $conn);
    $contactInfo = sanitizeInput($_POST['contactInfo'], $conn);
    $legalDescription = sanitizeInput($_POST['legalDescription'], $conn);
    $landLocation = sanitizeInput($_POST['landLocation'], $conn);
    $landArea = sanitizeInput($_POST['landArea'], $conn);
    $boundariesNorth = sanitizeInput($_POST['boundaries-north'], $conn);
    $boundariesSouth = sanitizeInput($_POST['boundaries-south'], $conn);
    $boundariesEast = sanitizeInput($_POST['boundaries-east'], $conn);
    $boundariesWest = sanitizeInput($_POST['boundaries-west'], $conn);
    $landUse = sanitizeInput($_POST['landUse'], $conn);

    // SQL query to insert data into the database
    $sql = "INSERT INTO subproject (Name, contact, Description, Location, Area, North, South, East, West, landUse)
    VALUES ('$landownerName', '$contactInfo', '$legalDescription', '$landLocation', '$landArea', '$boundariesNorth', '$boundariesSouth', '$boundariesEast', '$boundariesWest', '$landUse')";

if ($conn->query($sql) === TRUE) {
    // Alert message
    echo '<script>alert("New record created successfully"); window.location = "registration34.php";</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Land Registration Form</title>
    <link rel="stylesheet" href="registration34.css">
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
            
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #000;
        }

        .sidebar a:hover {
            color: red;
        }

    </style>
</head>

<body>
    <div class="sidebar">
        <ul>
            <li><a href="index.html">Home</a></li>
        </ul>
    </div>
    <div class="love">

        <div class="container">
            <h2>Land Registration Form</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="container">
                    <label for="landownerName">Full Name of Landowner:</label>
                    <input type="text" id="landownerName" name="landownerName" required>
                </div>
                <div class="container">
                    <label for="contactInfo">Contact Information:</label>
                    <input type="text" id="contactInfo" name="contactInfo" required>
                </div>
                <div class="container">
                    <label for="legalDescription">Legal Description of the Land:</label>
                    <textarea id="legalDescription" name="legalDescription" rows="4" required></textarea>
                </div>
                <div class="container">
                    <label for="landLocation">Address/Location of the Land:</label>
                    <input type="text" id="landLocation" name="landLocation" required>
                </div>
                <div class="container">
                    <label for="landArea">Total Land Area (in square meters/feet):</label>
                    <input type="text" id="landArea" name="landArea" required>
                </div>
                <div class="container">
                    <label for="boundaries">Boundaries:</label>
                    <label for="boundaries-north">North:</label><br>
                    <input type="text" id="boundaries-north" name="boundaries-north" required><br>
                    <label for="boundaries-south">South:</label><br><br>
                    <input type="text" id="boundaries-south" name="boundaries-south" required><br>
                    <label for="boundaries-east">East:</label><br>
                    <input type="text" id="boundaries-east" name="boundaries-east" required><br>
                    <label for="boundaries-west">West:</label><br>
                    <input type="text" id="boundaries-west" name="boundaries-west" required><br>
                </div>
                <div class="container">
                    <label for="landUse">Intended Land Use:</label>
                    <input type="text" id="landUse" name="landUse" required>
                </div>

                <button type="submit">submit</button>
                
            </form>
            <a href="registration100.php">next</a>
        </div>
    </div>
</body>

</html>
