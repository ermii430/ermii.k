<?php
session_start();
include 'connect.php';

if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    // Fetch the username before deleting the record
    $sql_fetch_username = "SELECT username FROM `register` WHERE id=$id";
    $result_fetch_username = mysqli_query($con, $sql_fetch_username);
    $row = mysqli_fetch_assoc($result_fetch_username);
    $username = $row['username'];

    $sql="DELETE FROM `register` WHERE id=$id";
    $result=mysqli_query($con,$sql);
    if($result){
        // Set a notification message with the username
        $_SESSION['notification'] = "The record for user '$username' has been deleted successfully.";
        // Execute JavaScript code to display the alert
        echo "<script>
                alert('User deleted successfully');
                window.location.href = 'display.php'; // Redirect to the page where the notification will be displayed
              </script>";
        exit();
    }
    else{
        // Handle errors if the deletion fails
        die(mysqli_error($con));
    }
}
?>
