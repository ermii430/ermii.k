<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $name = sanitizeInput($_POST['name']);
    $info = sanitizeInput($_POST['info']);
    $owner = sanitizeInput($_POST['owner']);
    $description = sanitizeInput($_POST['description']);
    $address = sanitizeInput($_POST['address']);
    $area = sanitizeInput($_POST['area']);
    $north = sanitizeInput($_POST['north']);
    $south = sanitizeInput($_POST['south']);
    $east = sanitizeInput($_POST['east']);
    $west = sanitizeInput($_POST['west']);

    // Prepare SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO users (name, inform, property, discription, address, area, north, south, east, west) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssss", $name, $info, $owner, $description, $address, $area, $north, $south, $east, $west);

    // Execute the prepared statement
   // Execute the prepared statement
if ($stmt->execute()) {
    // Display success message
    echo "<script>alert('New record created successfully!');";
    echo "window.location.href = 'record.php';</script>";
} else {
    // Display error message
    echo "Error: " . $stmt->error;
}


    // Close the statement
    $stmt->close();
}

// Function to sanitize input
function sanitizeInput($input) {
    // Trim whitespace and remove HTML tags
    $input = trim($input);
    $input = htmlspecialchars($input);
    return $input;
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="record.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #000;
        }
        .sidebar a:hover{
            color: red;
        }
        .footer {
    background-color: #333;
    padding: 50px 0;
}

.footer .container {
    display: flex;
    justify-content: space-between;
}

.footer-col {
    flex: 1;
    padding: 0 20px;
}

.footer-col h4 {
    color: #fff;
    font-size: 18px;
    margin-bottom: 20px;
}

.footer-col ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-col ul li {
    margin-bottom: 10px;
}

.footer-col ul li a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-col ul li a:hover {
    color: #000;
}

.social-links {
    margin-top: 20px;
}

.social-links a {
    color: #fff;
    text-decoration: none;
    margin-right: 10px;
    transition: color 0.3s ease;
}

.social-links a:hover {
    color: red;
}


    </style>
</head>
<body>
    <div class="sidebar">
        <ul>
            <li><a href="index.html">Home</a></li>
        </ul>
    </div>
    <div class="man">
        <form method="post" action=""> <!-- Updated form action and method -->
            <!-- Form content goes here -->
            <h2>record office form</h2>
            <label for="applicant-name">Name of Applicant/Organization:</label><br><br>
            <input type="text" id="applicant-name" name="name" required><br><br>
    
            <label for="contact-info">Contact Information (Phone, Email, Address):</label><br><br>
            <textarea rows="8" cols="10" id="contact-info" name="info" required></textarea>
    
            <h2>Property Details</h2>
            <label for="property-owner">Property Owner's Name:</label><br><br>
            <input type="text" id="property-owner" name="owner" required><br><br>
    
            <label for="legal-description">Legal Description of the Land:</label><br><br>
            <textarea rows="8" cols="10" id="legal-description" name="description" required></textarea><br><br>
    
            <label for="property-address">Address/Location of the Property:</label><br><br>
            <textarea rows="8" cols="10" id="property-address" name="address" required></textarea><br><br>
    
            <h3>Land Characteristics</h3>
            <label for="land-area">Total Land Area (in square meters/feet):</label><br><br>
            <input type="text" id="land-area" name="area" required><br><br>
    
            <label for="boundaries-north">Boundaries (attach a survey or provide detailed description):</label><br><br>
            <label for="boundaries-north">North:</label><br><br>
            <input type="text" name="north" required><br><br>
    
            <label for="boundaries-south">South:</label><br><br>
            <input type="text" name="south" required><br><br>
    
            <label for="boundaries-east">East:</label><br><br>
            <input type="text" name="east" required><br><br>
    
            <label for="boundaries-west">West:</label><br><br>
            <input type="text" name="west" required><br><br>
    
            <input type="submit" value="Submit" name="submit">
            <a href="record2.php">next</a>
    
        </form>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
    
</body>
</html>
