<?php
// Function to sanitize input data
function sanitizeInput($data, $conn) {
    $data = htmlspecialchars($data); // Convert special characters to HTML entities
    $data = trim($data); // Remove whitespace from the beginning and end of the string
    $data = stripslashes($data); // Remove backslashes (\)
    $data = mysqli_real_escape_string($conn, $data); // Escape special characters for use in an SQL statement
    return $data;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "project";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sanitize form inputs
    $owner_name = sanitizeInput($_POST['owner_name'], $conn);
    $land_use = sanitizeInput($_POST['land_use'], $conn);
    $compensation1 = sanitizeInput($_POST['compensation1'], $conn);
    $compensation2 = sanitizeInput($_POST['compensation2'], $conn);
    $prepared_by_name = sanitizeInput($_POST['prepared_by_name'], $conn);
    $role_of_job = sanitizeInput($_POST['role_of_job'], $conn);
    $date = $_POST['date']; // No need for sanitization as it's a date input

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO engner (owner_name, land_use, compensation1, compensation2, prepared_by_name, role_of_job, date) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $owner_name, $land_use, $compensation1, $compensation2, $prepared_by_name, $role_of_job, $date);

    // Execute SQL statement
    if ($stmt->execute()) {
        // Alert message
        echo "<script>alert('New record created successfully');</script>";
        // Redirect to another page
        echo "<script>window.location.href = 'engner.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="engner.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .sidebar {
            position: fixed;
            font-size: 23px;
            background: black;
        }
    
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
    
        .sidebar ul li {
            padding: 10px;
        }
    
        .sidebar ul li a {
            text-decoration: none;
            color: #fff;
        }
        .sidebar a:hover{
            color: red;
        }
        /* engner.css */

/* Reset default margin and padding */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

.site {
    margin-left: 250px; /* Adjust this according to your sidebar width */
    padding: 20px;
}

.site form {
    margin-bottom: 20px;
    border: 1px solid #000; /* Add border */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Add black shadow */
    padding: 20px; /* Add padding for inner content */
}

.site h1 {
    font-size: 24px;
    margin-bottom: 20px;
}

.site label {
    display: block;
    margin-bottom: 5px;
}

.site input[type="text"],
.site input[type="date"],
.site input[type="submit"] {
    width: 70%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.site input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    cursor: pointer;
}

.site input[type="submit"]:hover {
    background-color: #0056b3;
}

/* Name section styling */
.name {
    margin-top: 20px;
}

.name h2 {
    font-size: 20px;
    margin-bottom: 10px;
}
.site img {
    width: 40%; /* Set the width of the image to fill its container */
    max-width: 70%; /* Ensure the image doesn't exceed its original size */
    height: auto; /* Maintain aspect ratio */
    margin-bottom: 20px; /* Add some space below the image */
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.5); /* Adding shadow to the image */
}
.footer {
    background-color: #333;
    padding: 50px 0;
}

.footer .container {
    display: flex;
    justify-content: space-between;
}

.footer-col {
    flex: 1;
    padding: 0 20px;
}

.footer-col h4 {
    color: #fff;
    font-size: 18px;
    margin-bottom: 20px;
}

.footer-col ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-col ul li {
    margin-bottom: 10px;
}

.footer-col ul li a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-col ul li a:hover {
    color: #000;
}

.social-links {
    margin-top: 20px;
}

.social-links a {
    color: #fff;
    text-decoration: none;
    margin-right: 10px;
    transition: color 0.3s ease;
}

.social-links a:hover {
    color: #000;
}




    
    </style>
    <script type="text/javascript">
        function onlyNumberKey(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 31 &&(ASCIICode < 48 || ASCIICode > 57)){
                return false;
            }
        }
        function onlyCharacters(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 64 && (ASCIICode < 91 || ASCIICode > 96 && ASCIICode < 123)){
                return true;
            }
            else{
                return false;
            }
        }

    </script>

</head>
<body>
    <div class="sidebar">
        <ul>
          <li><a href="index.html">Home</a></li>
        </ul>
      </div>

    <div class="site">
        <h1>a site plan form showing the site</h1>
        <form action="" method="post">
            the name of the plan site owner:<br><input type="text" name="owner_name" placeholder="name"  onkeypress="return onlyCharacters(event)" required><br><br>
            land use:<br><input type="text" name="land_use"  onkeypress="return onlyCharacters(event)" required><br><br>
            <b>the level of space_1<sup>st</sup></b><br><br>
            <b>1. conditions of compensation</b><br><br>
            <input type="text" name="compensation1" required><br><br>
            <input type="text" name="compensation2" required><br><br>
            <b>2.the area of the earth(sq.m):</b>190346<br><br>
            <b>3.restrictions:</b><br><br>
            <b>the north:</b>bu'uura boru school<br>
            <b>the south:</b>hamaressa stream<br>
            <b>the west:</b>village<br>
            <b>the east:</b>village<br><br><br><br><br><br><br><br><br>
            <img src="plan.png" width="600" height="300" alt="photo"><br>
            <div class="name">
                <h2>prepared by</h2>
                <label>name</label>
                <input type="text" name="prepared_by_name"  onkeypress="return onlyCharacters(event)" required><br><br>
                <label>the role of the job</label>
                <input type="text" name="role_of_job"  onkeypress="return onlyCharacters(event)" required><br><br>
                <label>date</label>
                <input type="date" name="date" required><br><br>
            </div>
            <input type="submit" value="Submit" class="submit-button">
        </form>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
