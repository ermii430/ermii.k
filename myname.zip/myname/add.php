<?php
// Perform connection validation
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "teste";

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Connection failed
    die("Connection failed: " . $conn->connect_error);
}

// PHP validation and database insertion code
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['pswd'];
    $confirmPswd = $_POST['confirmPswd'];
    $role = $_POST['role']; // Added role variable

    // Add status variable
    $status = "1";

    // Check if passwords match
    if ($password != $confirmPswd) {
        // Passwords don't match, display error message
        echo "<script>alert('Passwords do not match.');</script>";
    } else {
        // Passwords match, proceed with insertion

        // Check for existing username or email
        $check_duplicate_user = "SELECT * FROM register WHERE email='$email' OR password='$password'";
        $result = $conn->query($check_duplicate_user);
        if ($result->num_rows > 0) {
            // Username or email already exists, display error message
            echo "<script>alert('Email or password already exists.');";
            echo "window.location.href = 'add.html';</script>";
        } else {
            // Insert information into database
            $sql = "INSERT INTO register (username, email, password, confirmpswd, role, status) 
                    VALUES ('$username', '$email', '$password', '$confirmPswd', '$role', '$status')";

            if ($conn->query($sql) === TRUE) {
                // Set a session variable for notification with username
                session_start();
                $_SESSION['notification'] = "New user '$username' added.";

                // Show JavaScript alert for successful addition
                echo "<script>alert('New user added.');</script>";

                // Redirect to display page
                header("Location: display.php?screen_location=" . urlencode($_POST['screen_location']));
                exit();
            } else {
                // Display error message
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
}

// Close the database connection
$conn->close();
?>