<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="fkr.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Update</title>
    <style type="text/css">
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #000;
        }

        .sidebar a:hover {
            color: red;
        }

        .content-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9rem;
            min-width: 400px;
        }

        .content-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
            font-weight: bold;
        }

        .content-table th,
        .content-table td {
            padding: 12px 15px;
        }

        .content-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .content-table tbody tr:nth-last-child(even) {
            background-color: #f3f3f3;
        }

        .content-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }

        .btn-group {
            display: flex;
            justify-content: space-around;
        }

        /* Additional CSS to fix scrolling */
        .container {
            max-height: 500px; /* Set max height for the container */
            overflow: auto; /* Enable scrolling if content exceeds max height */
        }
    </style>
</head>
<body>
<div class="sidebar">
    <ul>
        <li><a href="index.html">Home</a></li>
    </ul>
</div>
<div class="container">
    <div class="row justify-content-center mb-3"> <!-- Center the button -->
        <button class="button"><a href="add.html">Add User</a></button>
    </div>
    <table class="content-table">
        <thead>
        <tr>
            <th>SN</th>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
            <th>Confirm Password</th>
            <th>Role</th>
            <th>Action</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM register";
        $result = mysqli_query($con, $sql);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['id'];
                $username = $row['username'];
                $email = $row['email'];
                $password = $row['password'];
                $confirmpswd = $row['confirmpswd'];
                $role = $row['role'];
                $status = $row['status'];
                echo '<tr>
                <td>' . $id . '</td>
                <td>' . $username . '</td>
                <td>' . $email . '</td>
                <td>' . $password . '</td>
                <td>' . $confirmpswd . '</td>
                <td>' . $role . '</td>
               <td class="btn-group">
               <button class="btn btn-primary"><a href="update.php?updateid=' . $id . '"
               class="text-light">Update</a></button>
               <button class="btn btn-danger" onclick="return confirm(\'Are you sure you want to delete this record?\')"><a href="delete.php?deleteid=' . $id . '"
               class="text-light">Delete</a></button>
                &nbsp; <!-- Space between buttons -->
                <button class="btn btn-warning"><a href="deactivate.php?id=' . $id . '"
                   class="text-light">Deactivate</a></button>
               </td>
               <td>';
                // Display activate or deactivate button based on status
                if($status == 'activated') {
                    echo '<button class="btn btn-warning"><a href="deactivate.php?id=' . $id . '"
                   class="text-light">Deactivate</a></button>';
                } else {
                    echo '<button class="btn btn-success"><a href="activate.php?id=' . $id . '"
                   class="text-light">Activate</a></button>';
                }
                echo '</td></tr>';
            }
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
