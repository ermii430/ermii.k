<?php
// PHP code for database connection and form submission

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Update with your database password
$dbname = "project"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitizeInput($data, $conn) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Initialize variables
$tenant_name = $tenant_address = $tenant_district = $tenant_village = $partner_name = $land_location = $land_district = $land_village = $special_place = $property_number = $registered_number = $area = $restrictions_north = $restrictions_east = $restrictions_south = $restrictions_west = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $tenant_name = sanitizeInput($_POST["tenant-name"], $conn);
    $tenant_address = sanitizeInput($_POST["tenant-address"], $conn);
    $tenant_district = sanitizeInput($_POST["tenant-district"], $conn);
    $tenant_village = sanitizeInput($_POST["tenant-village"], $conn);
    $partner_name = sanitizeInput($_POST["partner-name"], $conn);
    $land_location = sanitizeInput($_POST["land-location"], $conn);
    $land_district = sanitizeInput($_POST["land-district"], $conn);
    $special_place = sanitizeInput($_POST["special-place"], $conn);
    $property_number = sanitizeInput($_POST["property-number"], $conn);
    $registered_number = sanitizeInput($_POST["registered-number"], $conn);
    $area = sanitizeInput($_POST["area"], $conn);
    $restrictions_north = sanitizeInput($_POST["restrictions-north"], $conn);
    $restrictions_east = sanitizeInput($_POST["restrictions-east"], $conn);
    $restrictions_south = sanitizeInput($_POST["restrictions-south"], $conn);
    $restrictions_west = sanitizeInput($_POST["restrictions-west"], $conn);

    // Insert data into database
    $sql = "INSERT INTO rent (name, address, district, village, parName, location, LDistrict, place, PNumber, registered, area, north,east,south,west)
            VALUES ('$tenant_name', '$tenant_address', '$tenant_district', '$tenant_village', '$partner_name', '$land_location', '$land_district', '$special_place', '$property_number', '$registered_number', '$area', '$restrictions_north', '$restrictions_east', '$restrictions_south', '$restrictions_west')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("New record created successfully"); window.location.href = "kiraa.php";</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>land</title>
    <link rel="stylesheet" href="kiraa.css">
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }
    
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
    
        .sidebar ul li {
            padding: 10px;
          
        }
    
        .sidebar ul li a {
            text-decoration: none;
            color: #000;
        }
        .sidebar a:hover{
            color: red;
        }
    
    </style>
    <script type="text/javascript">
        function onlyNumberKey(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 31 &&(ASCIICode < 48 || ASCIICode > 57)){
                return false;
            }
        }
        function onlyCharacters(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 64 && (ASCIICode < 91 || ASCIICode > 96 && ASCIICode < 123)){
                return true;
            }
            else{
                return false;
            }
        }

    </script>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="sidebar">
            <ul>
              <li><a href="index.html">Home</a></li>
            </ul>
          </div>
    <div class="all">
        <div class="nav"><br><br>
            <h1>farmland rent agreements</h1>
            <h3>article one : the parties to the lease agreement</h3>
        
        <p>the tenants of this agreement are Mr/Ms<input type="text" onkeypress="return onlyCharacters(event)" name="tenant-name" required><br>
            address<input type="text" onkeypress="return onlyCharacters(event)" name="tenant-address" required><br><br>
            district<input type="text" onkeypress="return onlyCharacters(event)" name="tenant-district" required>village<input type="text" onkeypress="return onlyCharacters(event)" name="tenant-village" required>
            and tenant referred to as Mr/Mrs<input type="text" onkeypress="return onlyCharacters(event)" name="partner-name" required> the seat of life is made grounded.(if the number of groups is more than two) they are gradually made partners.<br><br></p>
            <h3>article two: land lease description</h3>
            <p>land for rent in<input type="text" onkeypress="return onlyCharacters(event)" name="land-location" required>district, in<input type="text" onkeypress="return onlyCharacters(event)" name="land-district" required>village in the name of a special place<input type="text" onkeypress="return onlyCharacters(event)" name="special-place" required>unique property number<br><br><input type="text" onkeypress="return onlyNumberKey(event)" name="property-number" required>and registered with the number of area<input type="text" name="registered-number" required> ; the area is<input type="text" name="area" required>hectares.
                the restrictions are:<br><br>
                north:<input type="text" onkeypress="return onlyCharacters(event)" name="restrictions-north" required><br><br>
                east:<input type="text" onkeypress="return onlyCharacters(event)"  name="restrictions-east" required><br><br>
                south:<input type="text" onkeypress="return onlyCharacters(event)"  name="restrictions-south" required><br><br>
                west:<input type="text" onkeypress="return onlyCharacters(event)"  name="restrictions-west" required><br><br>
            </p>
            <input type="submit" value="submit" class="submit-button">
            <a href="essa.php">next</a>
    </div>
</div>
</form>
</body>
</html>
