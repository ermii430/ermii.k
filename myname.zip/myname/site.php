<?php
// PHP code for database connection and form submission

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Initialize variables
$owner_name = $property_address = $legal_description = $land_details = $land_area = $boundaries_north = $boundaries_south = $boundaries_east = $boundaries_west = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $owner_name = sanitizeInput($_POST["owner-name"]);
    $property_address = sanitizeInput($_POST["property-address"]);
    $legal_description = sanitizeInput($_POST["legal-description"]);
    $land_details = sanitizeInput($_POST["land-details"]);
    $land_area = sanitizeInput($_POST["land-area"]);
    $boundaries_north = sanitizeInput($_POST["boundaries-north"]);
    $boundaries_south = sanitizeInput($_POST["boundaries-south"]);
    $boundaries_east = sanitizeInput($_POST["boundaries-east"]);
    $boundaries_west = sanitizeInput($_POST["boundaries-west"]);

    // Insert data into database
    $sql = "INSERT INTO site (name, address, description, land_details, land_area, north, south, east, west)
            VALUES ('$owner_name', '$property_address', '$legal_description', '$land_details', '$land_area', '$boundaries_north', '$boundaries_south', '$boundaries_east', '$boundaries_west')";

if ($conn->query($sql) === TRUE) {
    echo '<script>alert("New record created successfully"); window.location.href = "site.php";</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Land Site Plan Form</title>
    <link rel="stylesheet" href="site.css">
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }
    
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
    
        .sidebar ul li {
            padding: 10px;
            background: black;
        }
    
        .sidebar ul li a {
            text-decoration: none;
            color: #fff;
        }
        .sidebar a:hover{
            color: red;
        }
    
    </style>
</head>
<body>
    <div class="sidebar">
        <ul>
            <li><a href="index.html">Home</a></li>
        </ul>
    </div>
    <div class="love">
        <div class="form-section">
            <h1>Land Site Plan Form</h1>
        </div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-section">
                <label for="owner-name">Property Owner's Name:</label><br><br>
                <input type="text" id="owner-name" name="owner-name" required>
            </div>

            <div class="form-section">
                <label for="property-address">Address of the Property:</label><br><br>
                <input type="text" id="property-address" name="property-address" required>
            </div>

            <div class="form-section">
                <label for="legal-description">Legal Description of the Land:</label><br><br>
                <textarea id="legal-description" name="legal-description"></textarea>
            </div>

            <div class="form-section">
                <label for="land-details">Land Details:</label><br><br>
                <textarea id="land-details" name="land-details"></textarea>
            </div>

            <div class="form-section">
                <label for="land-area">Total Land Area (in square meters/feet):</label><br><br>
                <input type="text" id="land-area" name="land-area" required>
            </div>

            <div class="form-section">
                <label for="boundaries-north">Boundaries (describe or sketch):</label><br><br>
                <label for="boundaries-north">North:</label><br><br>
                <input type="text" id="boundaries-north" name="boundaries-north" required><br><br>
                <label for="boundaries-south">South:</label><br><br>
                <input type="text" id="boundaries-south" name="boundaries-south" required><br><br>
                <label for="boundaries-east">East:</label><br>
                <input type="text" id="boundaries-east" name="boundaries-east" required><br><br>
                <label for="boundaries-west">West:</label><br>
                <input type="text" id="boundaries-west" name="boundaries-west" required><br><br>
            </div>
            <input type="submit" value="Submit" class="submit-button">
        </form>
        <a href="site2.php">next</a>
    </div>
</body>
</html>

