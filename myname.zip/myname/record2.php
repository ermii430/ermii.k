<?php
// Function to sanitize input
function sanitizeInput($input) {
    // Trim whitespace and remove HTML tags
    $input = trim($input);
    $input = htmlspecialchars($input);
    return $input;
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "myshop";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize input
    $zoning_classification = sanitizeInput($_POST['zoning-classification']);
    $intended_land_use = sanitizeInput($_POST['intended-land-use']);

    // Concatenate values of checkboxes into a single string
    $utilities_infrastructure = [];
    if (isset($_POST['water-supply'])) {
        $utilities_infrastructure[] = 'Water Supply';
    }
    if (isset($_POST['electricity-connection'])) {
        $utilities_infrastructure[] = 'Electricity Connection';
    }
    if (isset($_POST['sewer-system'])) {
        $utilities_infrastructure[] = 'Sewer System';
    }
    $utilities_infrastructure_str = implode(", ", $utilities_infrastructure);

    // Check if road access is provided
    $road_access = isset($_POST['road-access']) ? 'Road Access' : 'No Road Access';

    // Handle public transportation
    $public_transportation = isset($_POST['public-transportation']) ? implode(", ", $_POST['public-transportation']) : '';

    $environmental_restrictions = sanitizeInput($_POST['environmental-restrictions']);

    // Handle file upload if needed
    $targetDirectory = "./uploads2/";

    if (!file_exists($targetDirectory)) {
        mkdir($targetDirectory, 0777, true);
    }

    $targetFile = $targetDirectory . basename($_FILES["documents"]["name"]);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    if ($_FILES["documents"]["name"] != '') {
        // Attempt to upload file
        if (move_uploaded_file($_FILES["documents"]["tmp_name"], $targetFile)) {
            echo "<script>alert('The file " . htmlspecialchars(basename($_FILES["documents"]["name"])) . " has been uploaded.');</script>";        } else {
            echo "<script>alert('your file are uploaded!');</script>";
        }
    } else {
        echo "<script>alert('Please select a file to upload!');</script>";
        $uploadOk = 0;
    }

    if ($uploadOk == 1) {
        $additional_comments = sanitizeInput($_POST['additional-comments']);

        // Prepare SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO actor (classification, land_use, utilities_infrastructure, road, public, environmental, additional, document) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $zoning_classification, $intended_land_use, $utilities_infrastructure_str, $road_access, $public_transportation, $environmental_restrictions, $additional_comments, $targetFile);

        // Execute the prepared statement
        if ($stmt->execute()) {
            // Display success message and redirect if needed
            echo "<script>alert('Record added successfully!');</script>";
            // Redirect to another page if needed
            // echo "<script>window.location.href = 'your_redirect_page.php';</script>";
        } else {
            // Display error message
            echo "Error: " . $stmt->error;
        }
    }
}

       ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="record2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        
        .footer {
    background-color: #333;
    padding: 50px 0;
    margin-left: 190px;
}

.footer .container {
    display: flex;
    justify-content: space-between;
}

.footer-col {
    flex: 1;
    padding: 0 20px;
}

.footer-col h4 {
    color: #fff;
    font-size: 18px;
    margin-bottom: 20px;
}

.footer-col ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-col ul li {
    margin-bottom: 10px;
}

.footer-col ul li a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-col ul li a:hover {
    color: #000;
}

.social-links {
    margin-top: 20px;
}

.social-links a {
    color: #fff;
    text-decoration: none;
    margin-right: 10px;
    transition: color 0.3s ease;
}

.social-links a:hover {
    color: red;
}.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 200px;
    font-size: 23px;
    background-color: #333;
    color: #fff;
    height: 100%;
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

.sidebar ul li {
    padding: 10px;
}

.sidebar ul li a {
    text-decoration: none;
    color: #fff;
}

.sidebar ul li a:hover {
    color: red;
}

    </style>
</head>
<body>
<div class="sidebar">
        <ul>
            <li><a href="index.html">Home</a></li><br><br>
            <li><a href="josy.php">downloading file </a></li>
        </ul>
    </div>
    <div class="mach">
    <form method="post" enctype="multipart/form-data">
        <h2>Additional Information</h2>
        <h3>Land Use and Zoning</h3><br><br>
        <label for="zoning-classification">Current Zoning Classification:</label><br><br>
        <input type="text" id="zoning-classification" name="zoning-classification" required><br><br>
        
        <label for="intended-land-use">Intended Land Use (Residential, Commercial, Agricultural, etc.):</label><br><br>
        <input type="text" id="intended-land-use" name="intended-land-use" required><br><br>
        
        <h3>Utilities and Infrastructure</h3>
        <label for="water-supply">Water Supply:</label>
        <input type="checkbox" id="water-supply" name="water-supply">
        
        <label for="electricity-connection">Electricity Connection:</label>
        <input type="checkbox" id="electricity-connection" name="electricity-connection">
        
        <label for="sewer-system">Sewer System:</label>
        <input type="checkbox" id="sewer-system" name="sewer-system">
        
        <h3>Access and Transportation</h3>
        <label for="road-access">Road Access:</label>
        <input type="checkbox" id="road-access" name="road-access"><br><br>
        
        <label for="public-transportation">Nearest Public Transportation:</label>
        <input type="radio" id="bus" name="public-transportation[]" value="bus">
        <label for="bus">Bus</label>
        <input type="radio" id="train" name="public-transportation[]" value="train">
        <label for="train">Train</label>
        <input type="radio" id="other" name="public-transportation[]" value="other">
        <label for="other">Other</label>
        
        <h3>Environmental Considerations</h3>
        <label for="environmental-restrictions">Any Environmental Restrictions or Concerns:</label><br><br>
        <textarea id="environmental-restrictions" name="environmental-restrictions"></textarea>
        
        <h3>Documents Submitted</h3>
        <label for="documents">Attach Survey Maps, Deeds, or Any Relevant Documents:</label><br>
        <input type="file" id="documents" name="documents">
        
        <h3>Additional Comments</h3>
        <label for="additional-comments">Any Additional Notes or Comments:</label><br><br>
        <textarea rows="8" cols="10" id="additional-comments" name="additional-comments"></textarea>
        
        <input type="submit" value="Submit">
      </form>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
      
</body>
</html>
