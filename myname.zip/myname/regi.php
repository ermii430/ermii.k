<?php
$conn = new mysqli('localhost', 'root', '', 'project');
if (!$conn){
    die(mysqli_error($conn));
}

function display_data(){
    global $conn;
    $query = "SELECT * FROM subproject";
    $result = mysqli_query($conn, $query);
    return $result;
}

$result = display_data();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXPERIENCE REQUEST</title>
    <link rel="stylesheet" href="josy.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Downloading file</h2>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example3" class="display" style="min-width: 845px">
                                <thead>
                                    <tr text-align="center">
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>contact</th>
                                        <th>Description</th>
                                        <th>location</th>
                                        <th>Area</th>
                                        <th>North</th>
                                        <th>South</th>
                                        <th>East</th>
                                        <th>West</th>
                                        <th>Land Use</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                session_start();
                                while ($row = mysqli_fetch_assoc($result)){                                       
                                    ?>
                                    <tr>
                                        <td><?php echo $row['id'] ?></td> 
                                        <td><?php echo $row['Name']?></td>
                                        <td><?php echo $row['contact']?></td>
                                        <td><?php echo $row['Description']?></td>
                                        <td><?php echo $row['Location']?></td>
                                        <td><?php echo $row['Area']?></td>
                                        <td><?php echo $row['North']?></td>
                                        <td><?php echo $row['South']?></td>
                                        <td><?php echo $row['East']?></td>
                                        <td><?php echo $row['West']?></td>
                                        <td><?php echo $row['landUse']?></td>
                                        <td>
                                    </tr>
                                    <?php
                                }
                                session_destroy();
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a style =" display: inline-block;  margin-top: 20px; padding: 10px 20px; background-color: #007bff;  color: #fff;border-radius: 5px;transition: background-color 0.3s ease;  text-decoration: none;"href="josy2.php"> Next</a>

    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
