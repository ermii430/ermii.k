<?php
// Function to sanitize input
function sanitizeInput($conn, $input) {
    $input = trim($input);
    $input = mysqli_real_escape_string($conn, $input);
    return $input;
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $name_gift = sanitizeInput($conn, $_POST["name_gift"]);
    $date_gift = sanitizeInput($conn, $_POST["date_gift"]);
    $name_recipient = sanitizeInput($conn, $_POST["name_recipient"]);
    $date_recipient = sanitizeInput($conn, $_POST["date_recipient"]);
    $name_elderly = sanitizeInput($conn, $_POST["name_elderly"]);
    $date_elderly = sanitizeInput($conn, $_POST["date_elderly"]);
    
    

    // Your SQL query to insert data into the database
    $sql = "INSERT INTO new1 (name_gift, date_gift, name_recipient, date_recipient, name_elderly, date_elderly) VALUES ('$name_gift', '$date_gift', '$name_recipient', '$date_recipient', '$name_elderly', '$date_elderly')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("New record created successfully"); window.location.href = "new.php";</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="new.css">
    <script type="text/javascript">
        function onlyNumberKey(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 31 &&(ASCIICode < 48 || ASCIICode > 57)){
                return false;
            }
        }
        function onlyCharacters(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 64 && (ASCIICode < 91 || ASCIICode > 96 && ASCIICode < 123)){
                return true;
            }
            else{
                return false;
            }
        }
    </script>
</head>
<body>
<div class="row">
    <h2>Gift Agreement</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label>Gift Name</label><br>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="255" name="name_gift" required><br>
        <label>Gift Date</label><br>
        <input type="date" onkeypress="return onlyNumberKey(event)" name="date_gift" required><br>
</div>
<div class="var">
    <h2>Recipient Agreement</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label>Recipient Name</label><br>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="255" name="name_recipient" required><br>
        <label>Recipient Date</label><br>
        <input type="date" onkeypress="return onlyNumberKey(event)" name="date_recipient" required><br>
</div>
<div class="var">
    <h2>elderly</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label>elderly Name</label><br>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="255" name="name_elderly" required><br>
        <label>elderly Date</label><br>
        <input type="date" onkeypress="return onlyNumberKey(event)" name="date_elderly" required><br>
        <input type="submit" value="Submit" class="submit-button">
    </form>
</div>
</body>
</html>
