<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="diro.css">
</head>
<body>
    <div class="diro">
        <b>Right and Obligation of Tenants</b>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <p>1. This agreement is valid for the year <input type="text" name="year" required>, month <input type="text" name="month" required>, from <input type="text" name="from" required> for consecutive <input type="text" name="consecutive" required> years.
                At the time of approval of this agreement, it shall be effective from the law of the year <input type="text" name="effective_from" required> until the year <input type="text" name="effective_until" required></p><br><br>
            <p>1. Name of tenant <input type="text" name="tenant1_name" required>, date <input type="date" name="tenant1_date" required></p><br><br>
            <p>2. Name of tenant <input type="text" name="tenant2_name" required>, date <input type="date" name="tenant2_date" required></p><br><br>
            <b>3. Names of Witnesses</b><br>
            <p>1. <input type="text" name="witness1_name" required>, date <input type="date" name="witness1_date" required></p><br><br>
            <p>2. <input type="text" name="witness2_name" required>, date <input type="date" name="witness2_date" required></p><br><br>
            <p>3. <input type="text" name="witness3_name" required>, date <input type="date" name="witness3_date" required></p><br><br>
            <b>4. Name of Elders</b><br>
            <p>1. Name of the elder <input type="text" name="elder1_name" required>, date <input type="date" name="elder1_date" required></p><br><br>
            <p>2. Name of the elder <input type="text" name="elder2_name" required>, date <input type="date" name="elder2_date" required></p><br><br>
            <p>3. Name of the elder <input type="text" name="elder3_name" required>, date <input type="date" name="elder3_date" required></p><br><br>
            <p>4. Name of the elder <input type="text" name="elder4_name" required>, date <input type="date" name="elder4_date" required></p><br><br>
            <input type="submit" value="Submit" class="submit-button">
        </form>
    </div>
</body>
</html>

<?php
// Function to sanitize input
function sanitizeInput($conn, $input) {
    $input = trim($input);
    $input = mysqli_real_escape_string($conn, $input);
    return $input;
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    foreach ($_POST as $key => $value) {
        $_POST[$key] = sanitizeInput($conn, $value);
    }

    // Your SQL query to insert data into the database
    $sql = "INSERT INTO name (year, month, from_date, conYears, effectiveFrom, effectiveUntil, T1Name, T1Date, T2name, T2Date, W1Name, W1Date, W2Name, W2Date, W3Name, W3Date, E1Name, E1Date, E2Name, E2Date, E3Name, E3Date, E4Name, E4Date) 
            VALUES ('$_POST[year]', '$_POST[month]', '$_POST[from]', '$_POST[consecutive]', '$_POST[effective_from]', '$_POST[effective_until]', '$_POST[tenant1_name]', '$_POST[tenant1_date]', '$_POST[tenant2_name]', '$_POST[tenant2_date]', '$_POST[witness1_name]', '$_POST[witness1_date]', '$_POST[witness2_name]', '$_POST[witness2_date]', '$_POST[witness3_name]', '$_POST[witness3_date]', '$_POST[elder1_name]', '$_POST[elder1_date]', '$_POST[elder2_name]', '$_POST[elder2_date]', '$_POST[elder3_name]', '$_POST[elder3_date]', '$_POST[elder4_name]', '$_POST[elder4_date]')";

    
if ($conn->query($sql) === TRUE) {
    echo '<script>alert("New record created successfully"); window.location.href = "diro.php";</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}

// Close connection
$conn->close();
?>
