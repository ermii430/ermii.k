<?php
session_start();

// Check for notification message
if (isset($_SESSION['notification']) && !empty($_SESSION['notification'])) {
    // Display the notification
    echo '<div class="notification-container">';
    echo '<div class="notification">' . htmlspecialchars($_SESSION['notification']) . '</div>';
    echo '</div>';

    // Clear the session variable
    unset($_SESSION['notification']);
}

// ...existing code...
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="maretadm.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Global CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        /* Sidebar CSS */
.sidebar {
    position: fixed; /* Fixed position */
    top: 0; /* Align to the top of the viewport */
    font-size: 23px;
    background-color: #333;
    color: #fff;
    width: 200px;
    height: 100vh;
    padding-top: 20px;
    text-align: center;
    overflow-y: auto; /* Add scrollbar if content exceeds sidebar height */
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    padding: 10px;
}

.sidebar ul li a {
    text-decoration: none;
    color: #fff;
    display: block; /* Make list items block-level for full width */
}

.sidebar ul li ul {
    display: none;
    position: absolute;
    background-color: #333;
    width: 200px;
    text-align: left;
    border-radius: 0 0 5px 5px;
    z-index: 1;
}

.sidebar ul li:hover ul {
    display: block;
}

.sidebar ul li ul li {
    padding: 10px;
    border-bottom: 1px solid #fff;
}

.sidebar ul li ul li:last-child {
    border-bottom: none;
}

.sidebar ul li ul li a {
    color: #fff;
    text-decoration: none;
    font-size: 14px;
}

.sidebar ul li ul li a:hover {
    background-color: #555;
}
.sidebar a:hover{
    color: red;
}

.notification-icon {
    position: absolute;
    top: 10px;
    right: 10px;
    color: #fff;
    font-size: 24px;
    cursor: pointer;
    
}


        /* Content CSS */
        .content {
            margin-left: 220px; /* Adjusted to accommodate the sidebar */
            padding: 20px;
            text-align: center; /* Center-align content */
        }

        .content p {
            margin-bottom: 20px;
            text-align: justify; /* Justify text within paragraphs */
            display: inline-block; /* Centering block-level elements */
        }

        .content img {
            display: block;
            margin: 0 auto;
            margin-bottom: 20px;
        }

        /* Media Query */
        @media (max-width: 767px) {
            .content {
                margin-left: 0;
            }

            .sidebar {
                width: 100%; /* Sidebar takes full width on smaller screens */
                height: auto;
                padding-top: 0;
                text-align: left;
            }

            .notification-icon {
                position: static;
                margin-top: 10px;
                margin-right: 10px;
                float: right;
            }
        }
        
        /* Footer CSS */
        .footer {
            background-color: #24262b;
            color: #fff;
            padding: 50px 0;
            text-align: center;
            margin-left: 150px;
        }

        .footer .container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .footer-col {
            flex: 1;
            padding: 0 20px;
        }

        .footer-col h4 {
            font-size: 18px;
            margin-bottom: 20px;
            color: #fff;
        }

        .footer-col ul {
            list-style: none;
            padding: 0;
            margin-bottom: 20px;
            
        }

        .footer-col ul li {
            margin-bottom: 10px;
        }

        .footer-col ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 16px;
        }

        .social-links a {
            display: inline-block;
            background-color: #333;
            color: #fff;
            width: 40px;
            height: 40px;
            line-height: 40px;
            text-align: center;
            margin-right: 10px;
            border-radius: 50%;
        }

        .social-links a:hover {
            background-color: gray;
        }
        
ul li ul.dropdown li {
display: block;
background: #333;
margin: 2px 0px;
}
ul li ul.dropdown {
width:auto;
background: #00FF8C;
position: absolute;
z-index: 999;
display: none;
}

ul li a{
display: block;
padding: 20px 25px;
color: #FFF;
text-decoration: none;
text-align: center;
font-size: 16px;
}
.notification-container {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #000;
            color: white;
            padding: 15px;
            border-radius: 5px;
            z-index: 9999;
}
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="notification-icon" id="notificationContent">&#x1F514;</div>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="regi.php">Data of user registration</a></li>
            <li><a href="regg.php">Data of record office</a></li>

        </ul>

        <!-- Adjusted font size for this part -->
        <ul>
            <li>
                <a href="#">LAND ADMINISTRATION &#x25BE;</a>
                <ul class="dropdown">
                    <li><a href="hulum.php">Land use planning</a></li>
                    <li><a href="hulum.php">Rent agreement </a></li>
                    <li><a href="hulum.php">Gift agreement </a></li>
                    <li><a href="hulum.php">Site plan</a></li>
                    <li><a href="hulum.php">regulatory reporting</a></li>
                    <li><a href="hulum.php">Budget and Finance </a></li>
                </ul>
            </li>
        </ul>
    </div>

    <!-- Content -->
    <div class="content">
      <h1>LAND ADMINISTRATION</h1>
        <p>
            The role of a system administrator (sysadmin) involves managing and maintaining the IT infrastructure of an organization. Sysadmins play a critical role in ensuring that the organization's computer systems operate smoothly, securely, and efficiently. Here are some key aspects of a sysadmin's role:<br>
            <b>Server Management:</b> Sysadmins are responsible for installing, configuring, and maintaining servers. This includes managing operating systems, setting up user accounts, and ensuring server security.<br>
            <b>Network Management:</b> Sysadmins oversee the organization's network infrastructure, including routers, switches, firewalls, and wireless access points. They configure network devices, monitor network performance, and troubleshoot connectivity issues.<br>
            <b>System Security:</b> Protecting the organization's data and systems from security threats is a primary responsibility of sysadmins. They implement security measures such as firewalls, antivirus software, intrusion detection systems, and encryption protocols. They also conduct regular security audits and respond to security incidents.<br>
        </p>

        <!-- First Image -->
        <img src="lov.png" alt="First Image" style="width: 700px; height: 500px; margin-bottom: 20px; ">

        <!-- First Paragraph -->
        <p>
            In a land management system, the role of a system administrator is crucial for maintaining the infrastructure, ensuring data security, and supporting users. Here are some specific functions of a system administrator in a land management system:<br>
            <b>Infrastructure Management:</b><br>
            - Provisioning and maintaining hardware resources such as servers, storage systems, and networking equipment.<br>
            - Configuring and optimizing server environments to ensure efficient operation of the land management software.<br>
            - Monitoring system performance and capacity planning to accommodate the growing needs of the land management system.<br>
            <b>Software Management:</b><br>
            - Installing, configuring, and updating the land management software and related applications.<br>
            - Testing new software releases or updates in a controlled environment before deploying them to the production system.<br>
            - Troubleshooting software issues and collaborating with vendors or developers for resolution.<br>
            <b>Data Management:</b><br>
            - Setting up and managing databases to store land-related data securely.<br>
            - Implementing data backup and recovery procedures to prevent data loss and ensure business continuity.<br>
            - Monitoring data integrity and implementing measures to protect against data corruption or unauthorized access.<br>
        </p>

        <!-- Second Image -->
        <img src="laff.png" alt="Second Image" style="width: 700px; height: 500px; margin-bottom: 20px;">

        <!-- Second Paragraph -->
        <p>
            In a land management system, the responsibilities of a system administrator are critical for ensuring the smooth operation, security, and reliability of the system. Here's an overview of the responsibilities:<br>
            <b>Server Management:</b> System administrators are responsible for managing the servers that host the land management system. This includes configuring, maintaining, and optimizing server hardware and software to ensure reliable performance.<br>
            <b>Security Management:</b> Protecting sensitive land-related data is paramount. System administrators implement security measures such as firewalls, intrusion detection systems, access controls, and encryption to safeguard data from unauthorized access, breaches, and cyber threats.<br>
            <b>Data Backup and Recovery:</b> Regular backups of land-related data are essential to prevent data loss due to hardware failures, accidents, or cyberattacks. System administrators set up and manage backup systems and develop comprehensive recovery plans to restore data quickly in the event of a disaster.<br>
        </p>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
    
</body>
</html>
