<?php
// PHP code for database connection and form submission

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Update with your database password
$dbname = "project"; // Update with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitizeInput($data, $conn) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Initialize variables
$village_of = $land_is = $east = $west = $north = $south = $grant_recipient = $contract_of_gift = $recipient_agreement = $land = $area = $mr = $mr_mrs = $gift_of = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $village_of = sanitizeInput($_POST["village_of"], $conn);
    $land_is = sanitizeInput($_POST["land_is"], $conn);
    $east = sanitizeInput($_POST["east"], $conn);
    $west = sanitizeInput($_POST["west"], $conn);
    $north = sanitizeInput($_POST["north"], $conn);
    $south = sanitizeInput($_POST["south"], $conn);
    $grant_recipient = sanitizeInput($_POST["grant_recipient"], $conn);
    $contract_of_gift = sanitizeInput($_POST["contract_of_gift"], $conn);
    $recipient_agreement = sanitizeInput($_POST["recipient_agreement"], $conn);
    $land = sanitizeInput($_POST["land"], $conn);
    $area = sanitizeInput($_POST["area"], $conn);
    $mr = sanitizeInput($_POST["mr"], $conn);
    $mr_mrs = sanitizeInput($_POST["mr_mrs"], $conn);
    $gift_of = sanitizeInput($_POST["gift_of"], $conn);

    // Insert data into database
    $sql = "INSERT INTO yew (village_of, land_is, east, west, north, south, grantRecipient, contractGift, Ragreement, land, area, Mr, Mr_Mrs, gift_of)
            VALUES ('$village_of', '$land_is', '$east', '$west', '$north', '$south', '$grant_recipient', '$contract_of_gift', '$recipient_agreement', '$land', '$area', '$mr', '$mr_mrs', '$gift_of')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("New record created successfully"); window.location.href = "yew.php";</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>form</title>
    <link rel="stylesheet" href="yew.css">
    <script type="text/javascript">
        function onlyNumberKey(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 31 &&(ASCIICode < 48 || ASCIICode > 57)){
                return false;
            }
        }
        function onlyCharacters(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 64 && (ASCIICode < 91 || ASCIICode > 96 && ASCIICode < 123)){
                return true;
            }
            else{
                return false;
            }
        }

    </script>
</head>
<body>
    <form action="" method="post">
        <div class="name"><br><br>
        <p> we have signed the agreement for the farmland in which our names and addresses are mentioned above in the said farmland
            in the <label>village of</label>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="village_of" required><br>in the district of haramaya the area of the <label>land is</label> 
            <input type="text" onkeypress="return onlyNumberKey(event)" name="land_is" required>hectars the boundary of the land:<br>
            <label>east</label><br>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="east" required><br>
            <label>west</label><br>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="west" required><br>
            <label>north</label><br>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="north" required><br>
            <label>south</label><br>
            <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="south" required><br>
        </div>
        </p>
    <div class="all">
        <div class="my"><br><br>
    <p>we the agreement of the grant of <label>Mr/Mrs</label>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="grant_recipient" required>the recipient of the agreement to <label>Mr/Mrs</label> 
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="mr_mrs" required>of my willingness to know this certificate 
        of my land where signed:<br>
        <label>gift agreement</label><br>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="contract_of_gift" required><br>
        <label>recipient agreement</label><br>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="recipient_agreement" required><br><br>
        our <label>agreement</label>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="land" required>agreement of the recipient I certify by my signature that I give an irrevocable gift to the presence.<br>even if a third party offers this land to me if there is, I will take responsibility. 
        I am the land grant agreement recipient <label>Mr/mrs</label>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="mr" required>the land of <label>Mr/Ms</label>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="mr_mrs" required>the area of <label>hectares</label>
        <input type="text" onkeypress="return onlyNumberKey(event)" name="area" required>which I certify by my signature that I have received the gift of land from 
        the person who gave it to me in the presence of the witnesses.<br>we the elders of the country whose names are listed below between<label>Mr</label>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="mr" required>the land of Mr./Mrs <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="mr_mrs" required> we certify with our signatures that we have<br><br> seen and heard that he has given an irrevocable <label>gift of</label>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="gift_of" required> above the limit to <label>Mr/Mrs</label>
        <input type="text" onkeypress="return onlyCharacters(event)" maxlength="11" name="mr_mrs" required>this agreement is valid before the law<br><br>
        <input type="submit" value="Submit" class="submit-button">
        <a href="new.php">next</a>
    </p>
    </div>
</div>
</form>
</body>
</html>
