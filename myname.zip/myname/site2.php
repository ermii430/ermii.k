<?php
// PHP code for database connection and form submission

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitizeInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Initialize variables
$zoning_classification = $land_use = $notable_features = $utilities_water = $utilities_electricity = $utilities_sewer = $road_access = $public_transportation = $additional_notes = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $zoning_classification = sanitizeInput($_POST["zoning-classification"]);
    $land_use = sanitizeInput($_POST["land-use"]);
    $notable_features = sanitizeInput($_POST["notable-features"]);

    // Check if utilities-water checkbox is checked
    $utilities_water = isset($_POST["utilities-water"]) && $_POST["utilities-water"] === "Yes" ? 'Yes' : 'No';
    
    // Check if utilities-electricity checkbox is checked
    $utilities_electricity = isset($_POST["utilities-electricity"]) && $_POST["utilities-electricity"] === "Yes" ? 'Yes' : 'No';
    
    // Check if utilities-sewer checkbox is checked
    $utilities_sewer = isset($_POST["utilities-sewer"]) && $_POST["utilities-sewer"] === "Yes" ? 'Yes' : 'No';
    
    // Check if road-access checkbox is checked
    $road_access = isset($_POST["road-access"]) && $_POST["road-access"] === "Yes" ? 'Yes' : 'No';
    
    $public_transportation = sanitizeInput($_POST["public-transportation"]);
    $additional_notes = sanitizeInput($_POST["additional-notes"]);

    // Insert data into database
    $sql = "INSERT INTO site2 (classification, land_use, notable_features, water, electricity, sewer, road, public, additional_notes)
            VALUES ('$zoning_classification', '$land_use', '$notable_features', '$utilities_water', '$utilities_electricity', '$utilities_sewer', '$road_access', '$public_transportation', '$additional_notes')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("New record created successfully"); window.location.href = "site2.php";</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Land Site Plan Form</title>
    <link rel="stylesheet" href="site2.css">
    <script type="text/javascript">
        function onlyCharacters(evt){
            var ASCIICode = (evt.which) ? evt.which : evt.Keycode
            if(ASCIICode > 64 && (ASCIICode < 91 || ASCIICode > 96 && ASCIICode < 123)){
                return true;
            }
            else{
                return false;
            }
        }
    </script>
</head>
<body>
    <div class="love">
    <h1>Additional information</h1>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-section">
            <label for="zoning-classification">Zoning Classification:</label><br><br>
            <input type="text" id="zoning-classification" name="zoning-classification">
        </div>

        <div class="form-section">
            <label for="land-use">Land Use (Residential, Commercial, Industrial, Agricultural):</label><br><br>
            <input type="text" onkeypress="return onlyCharacters(event)" id="land-use" name="land-use">
        </div>

        <div class="form-section">
            <label for="notable-features">Notable Features or Restrictions:</label><br><br>
            <textarea id="notable-features" name="notable-features"></textarea>
        </div>

        <div class="form-section">
            <label for="utilities-water">Availability of Water Supply:</label>
            <input type="radio" id="utilities-water" name="utilities-water" value="Yes">
            <label class="checkbox-label" for="utilities-water">Yes</label>
            <input type="radio" id="utilities-water-no" name="utilities-water" value="No">
            <label class="checkbox-label" for="utilities-water-no">No</label>
        </div>

        <div class="form-section">
            <label for="utilities-electricity">Electricity Connection:</label>
            <input type="radio" id="utilities-electricity" name="utilities-electricity" value="Yes">
            <label class="checkbox-label" for="utilities-electricity">Yes</label>
            <input type="radio" id="utilities-electricity-no" name="utilities-electricity" value="No">
            <label class="checkbox-label" for="utilities-electricity-no">No</label>
        </div>

        <div class="form-section">
            <label for="utilities-sewer">Sewer System:</label>
            <input type="radio" id="utilities-sewer" name="utilities-sewer" value="Yes">
            <label class="checkbox-label" for="utilities-sewer">Yes</label>
            <input type="radio" id="utilities-sewer-no" name="utilities-sewer" value="No">
            <label class="checkbox-label" for="utilities-sewer-no">No</label>
        </div>

        <div class="form-section">
            <label for="road-access">Road Access:</label>
            <input type="radio" id="road-access" name="road-access" value="Yes">
            <label class="checkbox-label" for="road-access">Yes</label>
            <input type="radio" id="road-access-no" name="road-access" value="No">
            <label class="checkbox-label" for="road-access-no">No</label>
        </div>

        <div class="form-section">
            <label for="public-transportation">Nearest Public Transportation:</label><br><br>
            <input type="radio" id="public-transportation-bus" name="public-transportation" value="bus">
            <label class="checkbox-label" for="public-transportation-bus">Bus</label>
            <input type="radio" id="public-transportation-train" name="public-transportation" value="train">
            <label class="checkbox-label" for="public-transportation-train">Train</label>
            <input type="radio" id="public-transportation-other" name="public-transportation" value="other">
            <label class="checkbox-label" for="public-transportation-other">Other</label>
        </div>

        <div class="form-section">
            <label for="additional-notes">Additional Notes or Comments:</label><br><br>
            <textarea id="additional-notes" name="additional-notes"></textarea>
        </div>

        <input type="submit" value="Submit" class="submit-button">
    </form>
    </div>
</body>
</html>
