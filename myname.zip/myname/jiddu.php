<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Information</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

   <style>
    /* Reset CSS */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Body styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
}

/* Header styling */
header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #000;
    padding: 20px 120px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 100;
}

.logo {
    font-size: 25px;
    color: #fff;
    text-decoration: none;
    font-weight: 600;
}

nav a {
    font-size: 18px;
    color: #fff;
    text-decoration: none;
    font-weight: 500;
    margin-left: 35px;
    transition: .3s;
}

nav a:hover {
    color: #0ef;
}

/* Menu styling */
.menu {
    position: fixed;
    width: 100%;
    background-color: blue; /* Changed background color */
    padding: 10px 0;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Added box shadow */
    z-index: 999;
}

.menu ul {
    display: flex;
    justify-content: center;
    align-items: center;
}

.menu ul li {
    list-style: none;
    margin-left: 20px;
    font-size: 25px;
    font-family: serif;
}

.menu ul li a {
    text-decoration: none;
    color: #000;
    font-weight: bold;
    transition: 0.4s ease-in-out;
    padding: 10px;
}

.menu ul li a:hover {
    color: #fff;
}

.menu p {
    color: #fff;
    font-size: 16px;
    line-height: 1.6;
    margin-top: 20px;
    text-align: center; /* Center aligned */
}

/* Content styling */
.content {
    margin-top: 80px; /* Adjusted value to accommodate fixed menu */
    padding: 20px 120px;
}

.content p {
    margin-bottom: 20px;
}

.content img {
    display: block;
    margin: 20px auto;
    max-width: 100%;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.centered {
    text-align: center;
}

/* Footer styling */
.footer {
    background-color: #333;
    color: #fff;
    padding: 50px 0;
}

.container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.footer-col {
    flex: 1;
    padding: 0 20px;
}

.footer-col h4 {
    font-size: 18px;
    margin-bottom: 20px;
}

.footer-col ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-col ul li {
    margin-bottom: 10px;
}

.footer-col ul li a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-col ul li a:hover {
    color: #0ef;
}

.social-links {
    margin-top: 20px;
}

.social-links a {
    display: inline-block;
    width: 40px;
    height: 40px;
    background-color: #fff;
    text-align: center;
    line-height: 40px;
    margin-right: 10px;
    border-radius: 50%;
    transition: background-color 0.3s ease;
}

.social-links a:hover {
    background-color: #0ef;
}

/* Responsive footer */
@media (max-width: 768px) {
    .footer-col {
        flex-basis: 50%;
        margin-bottom: 30px;
    }
}


   </style>
</head>
<body>
    <header>
        <a href="#" class="logo">Land Management</a>
        <nav>
            <a href="index.html">Home</a>
            <a href="nam.html">About</a>
            <a href="contact.html">Contact</a>
            <a href="services.html">Service</a>
        </nav>
    </header><br><br><br>

    <div class="menu">
        <ul>
            <li><a href="kiraa.php">RENT</a></li>
            <li><a href="jirra.php">GIFT</a></li>
            <li><a href="registration34.php">REGISTER</a></li>
            <li><a href="site.php">SITE</a></li>
        </ul>
    </div><br>

    <div class="content">
        <p>
            Users are crucial in a land management system for several reasons:<br><br>

            Data Input: Users play a vital role in providing accurate and up-to-date information. They can input details about land parcels, boundaries, ownership, land use, and other relevant data. This data forms the foundation for effective land management and decision-making.<br>

            Verification: Users can verify the accuracy of the existing data in the system. By reviewing and confirming the information, they contribute to maintaining reliable and trustworthy data within the land management system.<br>

            Feedback and Corrections: Users can report errors, inconsistencies, or outdated information they come across. This feedback enables continuous improvement of the land management system by identifying and rectifying any inaccuracies or gaps.<br>

            Decision-making: Land management systems often include functionalities that allow users to analyze data, generate reports, and make informed decisions. Users benefit from accessing reliable and comprehensive information on land issues, helping them make better land-related decisions.<br>

            Collaboration and Communication: Users can engage with each other, share knowledge, and collaborate on land management activities. The system can facilitate communication, collaboration, and coordination among individuals or organizations involved in land management processes, fostering efficient and effective operations.<br>

            By involving users in the land management system, it becomes more inclusive, accurate, and responsive to the needs of various stakeholders. This ultimately leads to improved land governance, planning, and sustainable land use.
        </p>
        <div class="centered">
            <img src="pic.png" alt="First Image">
        </div>
        <p>
            Data Input: Users play a vital role in providing accurate and up-to-date information. They can input details about land parcels, boundaries, ownership, land use, and other relevant data. This data forms the foundation for effective land management and decision-making.
        </p>
        <div class="centered">
            <img src="pic2.png" alt="Second Image">
        </div>
        <p>
            Verification: Users can verify the accuracy of the existing data in the system. By reviewing and confirming the information, they contribute to maintaining reliable and trustworthy data within the land management system.
        </p>
    </div>


    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
