<?php
$con= new mysqli('localhost','root','','teste');
if ($con->connect_error) {
  die("connection failed:".$con->connect_error);
  if(!$con){
    die(mysqli_error($con));
  }
}
?>
