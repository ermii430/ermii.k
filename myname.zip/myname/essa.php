<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitizeInput($input) {
    global $conn;
    $input = trim($input);
    $input = mysqli_real_escape_string($conn, $input);
    return $input;
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $date1 = sanitizeInput($_POST["date1"]);
    $year1 = sanitizeInput($_POST["year1"]);
    $date2 = sanitizeInput($_POST["date2"]);
    $year2 = sanitizeInput($_POST["year2"]);
    $producePercentage = sanitizeInput($_POST["producePercentage"]);
    $supplyAmount1 = sanitizeInput($_POST["supplyAmount1"]);
    $supplyAmount2 = sanitizeInput($_POST["supplyAmount2"]);

    // Your SQL query to insert data into the database
    $sql = "INSERT INTO essa (date1, year1, date2, year2, percentage, supplyAmount1, supplyAmount2) VALUES ('$date1', '$year1', '$date2', '$year2', '$producePercentage', '$supplyAmount1', '$supplyAmount2')";
    if ($conn->query($sql) === TRUE) {
        // Set success message for alert
        echo "<script>alert('New record created successfully'); window.location = 'essa.php';</script>";
    } else {
        // Set error message for alert
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="essa.css">
</head>
<body>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="essa">
            <h3>Article 3: the amount of rent and the manner of payment during the validity of this agreement</h3>
            <p>
                1. this agreement is valid from <input type="date" name="date1" required> date, year <input type="text" name="year1" required>, to date <input type="date" name="date2" required>, the year <input type="text" name="year2" required> and the sum <br><br>
                2. the tenant shall produce a percentage <input type="text" name="producePercentage" required> of the produce from the land described in accordance with paragraph 2 and distribute it to the tenant while it is in the field. <br><br>
                3. the parties agreed that the total supply of enhancer calls would be covered by <input type="text" name="supplyAmount1" required> and <input type="text" name="supplyAmount2" required> <br>
            </p>
            <h3>article 4: rights and obligations of the tenant</h3>
            <p>
                1. the land shall be delivered by the tenant to the tenant in accordance with Article 3(1). <br>
                2. pay government taxes in the name of the tenant. <br>
                3. shall be responsible for any rights claims raised by the 3rd party. <br>
                4. area should not be rented outside of the specified use. <br>
                5. monitor the proper observance and implementation of soil and water protection works <br>
                6. if the owner transfers his rights to another, he shall continue the performance of the contract until the expiry of the contract. <br>
                7. if the agreement is prejudicial to the interests of these tenants and the children in custody at the time, the public authority may intervene in the children's interests <br>
            </p>
            <input type="submit" value="submit" class="submit-button">
            <a href="diro.php">next</a>
        </div>
    </form>
</body>
</html>
