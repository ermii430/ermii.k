<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Information</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

   <style>
    /* Reset CSS */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Body styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
}

/* Header styling */
header {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #000;
    padding: 20px 120px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 100;
}

.logo {
    font-size: 25px;
    color: #fff;
    text-decoration: none;
    font-weight: 600;
}

nav a {
    font-size: 18px;
    color: #fff;
    text-decoration: none;
    font-weight: 500;
    margin-left: 35px;
    transition: .3s;
}

nav a:hover {
    color: #0ef;
}

/* Menu styling */
.menu {
    position: fixed;
    width: 100%;
    background-color: blue; /* Changed background color */
    padding: 10px 0;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Added box shadow */
    z-index: 999;
}

.menu ul {
    display: flex;
    justify-content: center;
    align-items: center;
}

.menu ul li {
    list-style: none;
    margin-left: 20px;
    font-size: 25px;
    font-family: serif;
}

.menu ul li a {
    text-decoration: none;
    color: #fff;
    font-weight: bold;
    transition: 0.4s ease-in-out;
    padding: 10px;
}

.menu ul li a:hover {
    color: #000;
}

.menu p {
    color: #fff;
    font-size: 16px;
    line-height: 1.6;
    margin-top: 20px;
    text-align: center; /* Center aligned */
}

/* Content styling */
.content {
    margin-top: 80px; /* Adjusted value to accommodate fixed menu */
    padding: 20px 120px;
}

.content p {
    margin-bottom: 20px;
}

.content img {
    display: block;
    margin: 20px auto;
    max-width: 100%;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.centered {
    text-align: center;
}

/* Footer styling */
.footer {
    background-color: #333;
    color: #fff;
    padding: 50px 0;
}

.container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.footer-col {
    flex: 1;
    padding: 0 20px;
}

.footer-col h4 {
    font-size: 18px;
    margin-bottom: 20px;
}

.footer-col ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-col ul li {
    margin-bottom: 10px;
}

.footer-col ul li a {
    color: #fff;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-col ul li a:hover {
    color: #0ef;
}

.social-links {
    margin-top: 20px;
}

.social-links a {
    display: inline-block;
    width: 40px;
    height: 40px;
    background-color: #fff;
    text-align: center;
    line-height: 40px;
    margin-right: 10px;
    border-radius: 50%;
    transition: background-color 0.3s ease;
}

.social-links a:hover {
    background-color: #0ef;
}

/* Responsive footer */
@media (max-width: 768px) {
    .footer-col {
        flex-basis: 50%;
        margin-bottom: 30px;
    }
}


   </style>
</head>
<body>
    <header>
        <a href="#" class="logo">Land Management</a>
        <nav>
            <a href="index.html">Home</a>
            <a href="nam.html">About</a>
            <a href="contact.html">Contact</a>
            <a href="services.html">Service</a>
        </nav>
    </header><br><br><br>

    <div class="menu">
        <ul>
        <li><a href="engner.php">Form of Engineer</a></li>
            <li><a href="sit2.php">Data of Site Plan from Users</a></li>
        </ul>
    </div><br>

    <div class="content">
        <p>
        Engineers play a crucial role in land management systems by applying their technical expertise to design, implement, and maintain various aspects of land use and development. Here are some key roles of engineers in land management systems:<br>

<b>Surveying and Mapping:</b> Engineers use surveying techniques and tools to accurately measure and map land features. This information is essential for planning and development projects.<br>

<b>Infrastructure Design:</b> Engineers design infrastructure such as roads, bridges, drainage systems, and utilities to support land development and ensure efficient use of resources.<br>

<b>Environmental Impact Assessment:</b> Engineers assess the environmental impact of proposed land development projects and recommend measures to mitigate negative effects on ecosystems and natural resources.<br>

<b>Land Use Planning:</b> Engineers work with urban planners and policymakers to develop land use plans that balance economic, environmental, and social considerations. They help determine suitable locations for residential, commercial, industrial, and recreational development.<br>
        </p>
        <div class="centered">
            <img src="engin.png" alt="First Image">
        </div>
        <p>
        <b> Regulatory Compliance:</b> Engineers ensure that land development projects comply with local, state, and federal regulations and codes. They obtain necessary permits and approvals and ensure that projects adhere to zoning laws, environmental protection standards, and safety regulations.<br>

<b>Construction Management:</b> Engineers oversee the construction phase of land development projects. They manage contractors, monitor progress, and ensure that construction activities meet design specifications, quality standards, and safety requirements.<br>

<b>Geotechnical Engineering:</b> Engineers assess soil and subsurface conditions to determine their suitability for construction projects. They provide recommendations for foundation design, earthwork, and slope stability to ensure structural integrity and safety.<br>

<b>Water Resource Management:</b> Engineers design and manage water-related infrastructure such as stormwater drainage systems, irrigation networks, and flood control measures. They optimize water resource utilization, mitigate flood risks, and protect water quality and ecosystems.<br>

<b>Risk Assessment and Management:</b> Engineers identify potential risks and hazards associated with land development projects, such as geological hazards, environmental contamination, or natural disasters. They develop risk management strategies to minimize vulnerabilities and enhance project resilience.<br>
        </p>
        <div class="centered">
            <img src="en2.png" alt="Second Image">
        </div>
        <p>
        Engineers bring several advantages to land management systems:<br>

<b>Technical Expertise:</b> Engineers possess specialized knowledge and skills in areas such as surveying, design, construction, and environmental assessment, enabling them to address complex challenges in land management effectively.<br>

<b>Problem Solving:</b> Engineers are trained to analyze problems, identify constraints, and develop innovative solutions. They apply scientific principles and engineering methodologies to overcome obstacles and optimize land use and development.<br>

<b>Efficiency and Optimization:</b> Engineers optimize land management processes to maximize efficiency and resource utilization. They design infrastructure and systems that minimize waste, reduce costs, and enhance productivity.<br>

<b>Risk Management:</b> Engineers assess potential risks and hazards associated with land development projects and implement measures to mitigate them. They identify vulnerabilities and develop strategies to enhance project resilience and safety.<br>

<b>Regulatory Compliance:</b> Engineers ensure that land management projects comply with relevant regulations, codes, and standards. They navigate complex permitting processes, obtain necessary approvals, and ensure that projects adhere to legal and regulatory requirements.<br>

<b>Environmental Stewardship:</b> Engineers prioritize environmental sustainability in land management practices. They assess environmental impacts, promote conservation of natural resources, and integrate green infrastructure solutions to minimize ecological footprints.<br>

<b>Innovation and Technology Integration:</b> Engineers leverage advancements in technology and innovation to enhance land management practices. They utilize tools such as Geographic Information Systems (GIS), Building Information Modeling (BIM), and remote sensing to gather data, analyze trends, and inform decision-making.<br>
        </p>
    </div>


    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
