<?php
// Get the file name from the request parameter
$filename = $_GET['file'];

// Set the Content-Type header based on the file extension
$file_extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
switch ($file_extension) {
    case 'pdf':
        header('Content-Type: application/pdf');
        break;
    case 'doc':
    case 'docx':
        header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        break;
    case 'xls':
    case 'xlsx':
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        break;
    default:
        header('Content-Type: application/octet-stream');
}

// Set the Content-Disposition header to initiate the download
header('Content-Disposition: attachment; filename="' . basename($filename) . '"');

// Read the file and send its contents to the browser
readfile($filename);