<?php
session_start();

// Check for notification message
if (isset($_SESSION['notification']) && !empty($_SESSION['notification'])) {
    // Display the notification
    echo '<div class="notification-container">';
    echo '<div class="notification">' . htmlspecialchars($_SESSION['notification']) . '</div>';
    echo '</div>';

    // Clear the session variable
    unset($_SESSION['notification']);
}

// ...existing code...
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Global CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        /* Sidebar CSS */
.sidebar {
    position: fixed; /* Fixed position */
    top: 0; /* Align to the top of the viewport */
    font-size: 23px;
    background-color: #333;
    color: #fff;
    width: 200px;
    height: 100vh;
    padding-top: 20px;
    text-align: center;
    overflow-y: auto; /* Add scrollbar if content exceeds sidebar height */
}

.sidebar ul {
    list-style-type: none;
    padding: 0;
}

.sidebar ul li {
    padding: 10px;
}

.sidebar ul li a {
    font-family: serif;
    text-decoration: none;
    color: #fff;
    display: block; /* Make list items block-level for full width */
}

.sidebar ul li ul {
    display: none;
    position: absolute;
    background-color: #333;
    width: 200px;
    text-align: left;
    border-radius: 0 0 5px 5px;
    z-index: 1;
}

.sidebar ul li:hover ul {
    display: block;
}

.sidebar ul li ul li {
    padding: 10px;
    border-bottom: 1px solid #fff;
}

.sidebar ul li ul li:last-child {
    border-bottom: none;
}

.sidebar ul li ul li a {
    color: #fff;
    text-decoration: none;
    font-size: 14px;
}

.sidebar ul li ul li a:hover {
    background-color: #555;
}
.sidebar a:hover{
    color: red;
}

.notification-icon {
    position: absolute;
    top: 10px;
    right: 10px;
    color: #fff;
    font-size: 24px;
    cursor: pointer;
    
}


        /* Content CSS */
        .content {
            margin-left: 220px; /* Adjusted to accommodate the sidebar */
            padding: 20px;
            text-align: center; /* Center-align content */
        }

        .content p {
            margin-bottom: 20px;
            text-align: justify; /* Justify text within paragraphs */
            display: inline-block; /* Centering block-level elements */
        }

        .content img {
            display: block;
            margin: 0 auto;
            margin-bottom: 20px;
        }

        /* Media Query */
        @media (max-width: 767px) {
            .content {
                margin-left: 0;
            }

            .sidebar {
                width: 100%; /* Sidebar takes full width on smaller screens */
                height: auto;
                padding-top: 0;
                text-align: left;
            }

            .notification-icon {
                position: static;
                margin-top: 10px;
                margin-right: 10px;
                float: right;
            }
        }
        
        /* Footer CSS */
        .footer {
            background-color: #24262b;
            color: #fff;
            padding: 50px 0;
            text-align: center;
            margin-left: 150px;
        }

        .footer .container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .footer-col {
            flex: 1;
            padding: 0 20px;
        }

        .footer-col h4 {
            font-size: 18px;
            margin-bottom: 20px;
            color: #fff;
        }

        .footer-col ul {
            list-style: none;
            padding: 0;
            margin-bottom: 20px;
            
        }

        .footer-col ul li {
            margin-bottom: 10px;
        }

        .footer-col ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 16px;
        }

        .social-links a {
            display: inline-block;
            background-color: #333;
            color: #fff;
            width: 40px;
            height: 40px;
            line-height: 40px;
            text-align: center;
            margin-right: 10px;
            border-radius: 50%;
        }

        .social-links a:hover {
            background-color: gray;
        }
        
ul li ul.dropdown li {
display: block;
background: #333;
margin: 2px 0px;
}
ul li ul.dropdown {
width:auto;
background: #00FF8C;
position: absolute;
z-index: 999;
display: none;
}

ul li a{
display: block;
padding: 20px 25px;
color: #FFF;
text-decoration: none;
text-align: center;
font-size: 16px;
}
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="record.php">Form of record officer</a></li>
            <li><a href="regi.php">Data of user register</a></li>
            <li><a href="kiraa2.php">Data of Rent from users</a></li>
            <li><a href="jirra2.php">Data of Gift from users</a></li>
            <li><a href="sit2.php">Data of Site from users</a></li>
            <li><a href="eng2.php">Data of Engineer</a></li>

        </ul>

        <!-- Adjusted font size for this part -->
        
    </div>

    <!-- Content -->
    <div class="content">
      <h1>RECORD OFFICER</h1>
        <p>
        <b>User Authentication:</b> Implement a login system for record officers to access the land management system securely.<br>

<b>Dashboard:</b> Upon login, provide a dashboard where officers can see an overview of their tasks, pending records, notifications, etc.<br>

<b>Record Management:</b>
    Add New Records: Allow officers to add new land records into the system. This could include details such as owner information, land size, location, usage, legal status, etc.<br>
    Update Records: Enable officers to update existing records if there are any changes or corrections.<br>
    Delete Records: Provide the option to delete records if needed, with appropriate permissions and safeguards.<br>
    Search and Filter: Implement search and filter functionalities to allow officers to quickly find specific records based on various criteria.<br>

<b>Document Management:</b>
    Allow officers to upload and manage related documents such as deeds, contracts, surveys, etc., associated with land records.
    Ensure proper categorization and version control for documents.<br><br>

<b>Reports and Analytics:</b> Provide tools for generating reports and analytics on land records, such as land usage statistics, ownership distribution, pending tasks, etc.<br>

<b>Notifications:</b> Implement a notification system to alert officers about pending tasks, upcoming deadlines, or any changes in records they are responsible for.<br>

<b>Audit Trail:</b> Maintain an audit trail to track all activities performed by officers within the system, including record modifications, document uploads, etc.<br>

<b>Access Control:</b> Enforce role-based access control to ensure that officers can only access and modify records within their jurisdiction or assigned areas.<br>
        </p>

        <!-- First Image -->
        <img src="Sc.png" alt="First Image" style="width: 700px; height: 500px; margin-bottom: 20px; ">

        <!-- First Paragraph -->
        <p>
        The role of a record officer in a land management system is critical for maintaining accurate and up-to-date records of land ownership, usage, transactions, and related documents. Here are some key responsibilities and tasks of a record officer:<br>

<b>Record Creation and Maintenance:</b> Record officers are responsible for creating new records in the land management system. This includes entering details about land parcels, such as ownership information, boundaries, legal descriptions, and any relevant documents.<br>

<b>Data Entry and Verification:</b> They ensure that all information entered into the system is accurate and up-to-date. This may involve verifying information provided by landowners, surveyors, or other stakeholders.<br>

<b>Record Updates:</b> Record officers update existing records as needed, such as when there are changes in land ownership, boundaries, or legal status. They also update records based on new information or documents received.<br>

<b>Document Management:</b> They manage documents related to land records, such as deeds, titles, surveys, permits, and zoning documents. This includes uploading, categorizing, indexing, and maintaining the integrity of these documents within the system.<br>
        </p>

        <!-- Second Image -->
        <img src="khat.png" alt="Second Image" style="width: 700px; height: 500px; margin-bottom: 20px;">

        <!-- Second Paragraph -->
        <p>
        Record officers bring several advantages to a land management system and the organization as a whole:<br>

<b>Data Accuracy:</b> Record officers ensure that land records are accurate, up-to-date, and consistent. Their attention to detail and verification processes reduce errors and discrepancies in the system, improving data reliability.<br>

<b>Compliance and Legal Assurance:</b> Record officers ensure that land records comply with legal and regulatory requirements. By adhering to relevant laws, regulations, and industry standards, they mitigate legal risks and ensure the organization's compliance with property and land-use regulations.<br>

<b>Efficient Record Management:</b> Record officers streamline the process of managing land records and related documents. Their organizational skills, categorization techniques, and document management strategies improve efficiency and accessibility, allowing stakeholders to retrieve information quickly and effectively.<br>

<b>Enhanced Decision-Making:</b> Accurate and reliable land records provided by record officers serve as a foundation for informed decision-making. Stakeholders, including policymakers, land developers, and investors, can rely on trustworthy data to assess opportunities, plan projects, and allocate resources effectively.<br>

<b>Transparency and Accountability:</b> By maintaining transparent and accessible land records, record officers promote accountability and transparency within the organization and the community. Stakeholders can access relevant information and monitor land-related activities, fostering trust and confidence in the land management process.<br>

<b>Risk Management:</b> Record officers identify and mitigate risks associated with land records, such as data loss, unauthorized access, and compliance failures. Their proactive approach to risk management helps safeguard sensitive information and protect the organization's reputation and interests.<br>
        </p>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Services</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Get Help</h4>
                <ul>
                    <li><a href="#">Documentation and Guides</a></li>
                    <li><a href="#">Support Portals or Help Centers</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Online Shop</h4>
                <ul>
                    <li><a href="#">Subscription Plans</a></li>
                    <li><a href="#">Software Licenses</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>
        </div>
    </footer>
    
</body>
</html>
