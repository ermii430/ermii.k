<?php
session_start();
include 'connect.php';

// Check if updateid is set in the URL
if(isset($_GET['updateid'])) {
    $id = $_GET['updateid'];
    
    // Fetch user data from the database
    $sql = "SELECT * FROM register WHERE id = $id";
    $result = mysqli_query($con, $sql);
    
    // Check if user exists
    if(mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $email = $row['email'];
        $username = $row['username'];
        $password = $row['password'];
        $confirmpswd = $row['confirmpswd'];
        $role = $row['role'];
        
        // Store the previous username
        $previous_username = $username;
        
        // Check if the form is submitted
        if(isset($_POST['submit'])){
            $email = mysqli_real_escape_string($con, $_POST['email']);
            $username = mysqli_real_escape_string($con, $_POST['username']);
            $password = mysqli_real_escape_string($con, $_POST['password']);
            $confirmpswd = mysqli_real_escape_string($con, $_POST['confirmpswd']);
            $role = mysqli_real_escape_string($con, $_POST['role']);
            
            // Update user data in the database
            $sql = "UPDATE register SET email='$email', username='$username', password='$password', confirmpswd='$confirmpswd', role='$role' WHERE id=$id";
            $result = mysqli_query($con, $sql);
            
            // Check if update was successful
            if ($result) {
                $_SESSION['notification'] = "Username of User updated from '$previous_username' to '$username'!";
                echo "<script>
                        alert('User updated successfully');
                        window.location.href = 'display.php';
                      </script>";
                exit();
            } else {
                die(mysqli_error($con));
            }
        }
    } else {
        // Redirect if user does not exist
        header("Location: display.php");
        exit();
    }
} else {
    // Redirect if updateid is not set
    header("Location: display.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="fkr.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <title>Update User</title>
    <style>
        .title {
            width: 60%;
            margin-left: 200px;
        }
        .row {
            width: 60%;
            margin-left: 200px;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            font-size: 23px;
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 10px;
        }
        .sidebar ul li a {
            text-decoration: none;
            color: #000;
        }
        .sidebar a:hover {
            color: red;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <ul>
            <li><a href="index.html">Home</a></li>
        </ul>
    </div>
    <div class="container">
        <div class="wrapper">
            <div class="title"><span>Update User</span></div>
            <form action="" method="POST">
                <div class="row">
                    <input type="email" name="email" value="<?php echo $email; ?>" required>
                </div>
                <div class="row">
                    <input type="text" name="username" value="<?php echo $username; ?>" required>
                </div>
                <div class="row">
                    <input type="password" name="password" value="<?php echo $password; ?>" required>
                </div>
                <div class="row">
                    <input type="password" name="confirmpswd" value="<?php echo $confirmpswd; ?>" required>
                </div>
                <div class="row">
                    <input type="text" name="role" value="<?php echo $role; ?>" required>
                </div>
                <div class="row button">
                    <input type="submit" name="submit" value="Update">
                    <a href="display.php">Back</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
