<?php
include 'connect.php';

// Check if the activateid parameter is set in the URL
if(isset($_GET['activateid'])) {
    // Sanitize the activateid parameter to prevent SQL injection
    $activateid = mysqli_real_escape_string($con, $_GET['activateid']);

    // Update the user status to "activated" in the database
    $sql = "UPDATE ermii2 SET status = 'activated' WHERE id = $activateid";

    if(mysqli_query($con, $sql)) {
        // User activated successfully
        echo "User activated successfully!";
    } else {
        // Error occurred while activating user
        echo "Error: " . mysqli_error($con);
    }
} else {
    // activateid parameter is missing
    echo "Error: activateid parameter is missing!";
}

// Close database connection
mysqli_close($con);
?>
