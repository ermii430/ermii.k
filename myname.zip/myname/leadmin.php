<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Information</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }

        .content {
            margin-top: 100px;
            padding: 0 120px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .overview {
            margin-bottom: 50px;
            text-align: center;
        }

        .overview p, .overview h2 {
            text-align: center;
        }

        img {
            display: block;
            margin: 0 auto;
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }

        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: #000;
            padding: 20px 120px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
        }

        .logo {
            font-size: 25px;
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }

        nav {
            display: flex;
        }

        nav a {
            font-size: 18px;
            color: #fff;
            text-decoration: none;
            font-weight: 500;
            margin-left: 35px;
            transition: .3s;
        }

        nav a:hover {
            color: #0ef;
        }

        .index {
            position: fixed;
            height: 40px;
            width: 100%;
            background: blueviolet;
            z-index: 1000;
            margin-top: -35px;
        }

        .index ul {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0;
            list-style: none;
            margin: 0;
            font-size: 30px;
        }

        .index ul li {
            margin: 0 10px;
            margin-left: 100px;
            margin-right: 200px;
        }

        .index ul li a {
            text-decoration: none;
            color: #fff;
            font-family: Arial, sans-serif;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .index ul li a:hover {
            color: #000;
        }

        .footer {
            background-color: #24262b;
            padding: 70px 0;
            color: #fff;
            text-align: center;
        }

        .footer .container {
            max-width: 1170px;
            margin: auto;
        }

        .footer .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .footer-col {
            width: 25%;
            padding: 0 15px;
            margin-bottom: 30px;
        }

        .footer-col h4 {
            font-size: 18px;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .footer-col ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .footer-col ul li {
            margin-bottom: 10px;
        }

        .footer-col ul li a {
            color: #bbb;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-col ul li a:hover {
            color: #fff;
        }

        .social-links {
            margin-top: 20px;
        }

        .social-links a {
            display: inline-block;
            height: 40px;
            width: 40px;
            background-color: rgba(255, 255, 255, 0.2);
            margin-right: 10px;
            border-radius: 50%;
            line-height: 40px;
            text-align: center;
            color: #fff;
            transition: background-color 0.3s ease;
        }

        .social-links a:hover {
            background-color: #fff;
            color: #24262b;
        }

        @media(max-width: 767px) {
            header {
                padding: 20px;
            }

            .content {
                padding: 0 20px;
            }

            .overview h2 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <header>
        <a href="#" class="logo">Land Management</a>
        <nav>
            <a href="index.html">Home</a>
            <a href="nam.html">About</a>
            <a href="contact.html">Contact</a>
            <a href="services.html">Services</a>
        </nav>
    </header>
    <div class="index">
        <ul>
            <li><a href="add.html">Add</a></li>
            <li><a href="display.php">Display</a></li>
        </ul>
    </div>

    <div class="content">
        <div class="overview"><br><br><br><br>
            <h2>Responsibilities of an Admin in Land Management System</h2><br>
            <p>Here's a brief overview of the responsibilities and functions of an admin in a land management system:</p>
            <ul>
                <li><strong>User Management:</strong> The admin is responsible for managing user accounts within the system. This includes creating new user accounts, modifying existing ones, and deactivating or removing accounts as needed. User management ensures that only authorized individuals have access to the system.</li><br><br>
                <li><strong>Access Control:</strong> Admins set access permissions and privileges for different user roles within the system. They determine which users have access to specific features, data, or functionalities based on their roles and responsibilities. Access control helps maintain data confidentiality and integrity.</li><br><br>
                <li><strong>System Configuration and Maintenance:</strong> Admins handle system configuration tasks such as setting up databases, configuring server settings, and managing system resources. They also perform routine maintenance tasks like software updates, backups, and system monitoring to ensure optimal performance and security.</li>
            </ul>
        </div>

        <img src="haroe.png" width ="80%" alt="Image">

        <div class="overview"><br><br>
            <h2>Components of Land Management System</h2><br>
            <p>A land management system in Haramaya City, or any city for that matter, may include components such as:</p>
            <ul>
                <li><strong>Land Records Management:</strong> Digitized records of land parcels, ownership information, land use classifications, and historical data.</li>
                <li><strong>Zoning and Planning:</strong> Tools for managing land use zoning regulations, urban planning, and development permits.</li>
                <li><strong>Cadastre and Mapping:</strong> Geospatial data management systems for accurate mapping, cadastral surveys, and land parcel identification.</li>
            </ul>
        </div>

        <img src="se.png" width="80%"alt="Image">
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col">
                    <h4>Company</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Our Services</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Get Help</h4>
                    <ul>
                        <li><a href="#">Documentation and Guides</a></li>
                        <li><a href="#">Support Portals or Help Centers</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Online Shop</h4>
                    <ul>
                        <li><a href="#">Subscription Plans</a></li>
                        <li><a href="#">Software Licenses</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Follow Us</h4>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-google"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
